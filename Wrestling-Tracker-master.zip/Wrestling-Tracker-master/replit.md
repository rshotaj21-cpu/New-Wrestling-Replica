# Workspace

## Overview

Freestyle Wrestling Notes - a personal training tracker app for freestyle wrestlers. Tracks training sessions, sparring, techniques, competitions (with wins/losses/match records), focus/drill sessions, and has a calendar view and a full Stats analytics page.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite, TailwindCSS, React Query, framer-motion, react-hook-form, date-fns

## Structure

```text
artifacts-monorepo/
├── artifacts/
│   ├── api-server/         # Express API server (all routes)
│   └── wrestling-notes/    # React + Vite frontend app (at /)
├── lib/
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Features

- **Dashboard**: Stats overview, recent sessions, upcoming competitions
- **Sessions**: Log training sessions with duration, rating, type, wentWell/needsWork notes
- **Sparring**: Track sparring rounds, round duration, endurance/rounds ratings
- **Techniques**: Log techniques by category (takedown, scramble, etc.) with reps in sparring and success rate
- **Calendar**: Monthly calendar view of sessions with week/month/year counts
- **Focus**: Drill timer + rep tracker for focused technique training
- **Competitions**: Track events with wins, losses, total matches, weight class, result

## DB Schema Tables

- `sessions` - Training sessions
- `sparring` - Sparring sessions
- `techniques` - Individual techniques
- `competitions` - Competitions with wins/losses/totalMatches
- `focus_sessions` - Focus/drill sessions

## API Routes

All routes at `/api/*`:
- `GET/POST /api/sessions`, `GET/PUT/DELETE /api/sessions/:id`
- `GET/POST /api/sparring`, `GET/PUT/DELETE /api/sparring/:id`
- `GET/POST /api/techniques`, `PUT/DELETE /api/techniques/:id`
- `GET/POST /api/competitions`, `GET/PUT/DELETE /api/competitions/:id`
- `GET/POST /api/focus`, `PUT/DELETE /api/focus/:id`
- `GET /api/stats`

## Packages

### `artifacts/api-server` (`@workspace/api-server`)

Express 5 API server. Routes live in `src/routes/`.

### `artifacts/wrestling-notes` (`@workspace/wrestling-notes`)

React + Vite frontend at `/`. Uses React Query hooks from `@workspace/api-client-react`.

### `lib/db` (`@workspace/db`)

Database layer using Drizzle ORM with PostgreSQL.

- `pnpm --filter @workspace/db run push` — push schema changes

### `lib/api-spec` (`@workspace/api-spec`)

OpenAPI spec + codegen.

- `pnpm --filter @workspace/api-spec run codegen` — regenerate clients
