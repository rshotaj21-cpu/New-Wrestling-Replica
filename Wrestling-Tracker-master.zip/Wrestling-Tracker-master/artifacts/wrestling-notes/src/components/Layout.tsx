import { Link, useLocation } from "wouter";
import { Home, Dumbbell, Swords, BookOpen, Calendar, Target, Trophy, Users, BarChart3, Weight } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/sessions", label: "Sessions", icon: Dumbbell },
  { href: "/sparring", label: "Sparring", icon: Swords },
  { href: "/strength-conditioning", label: "S&C", icon: Weight },
  { href: "/techniques", label: "Library", icon: BookOpen },
  { href: "/focus", label: "Focus", icon: Target },
  { href: "/calendar", label: "Calendar", icon: Calendar },
  { href: "/competitions", label: "Comps", icon: Trophy },
  { href: "/one-on-one", label: "1-2-1", icon: Users },
  { href: "/stats", label: "Stats", icon: BarChart3 },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      {/* Mobile Top Header */}
      <header className="md:hidden flex items-center justify-between p-4 border-b border-border/50 bg-background/80 backdrop-blur-lg sticky top-0 z-40">
        <h1 className="font-display font-bold text-xl tracking-wider text-primary uppercase italic">
          Wrestling<span className="text-foreground">Notes</span>
        </h1>
      </header>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-56 border-r border-border/50 bg-card/30 p-4 sticky top-0 h-screen shrink-0">
        <h1 className="font-display font-bold text-xl tracking-wider text-primary uppercase italic mb-6">
          Wrestling<span className="text-foreground">Notes</span>
        </h1>
        <nav className="flex-1 space-y-0.5">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className="block">
                <div className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group cursor-pointer",
                  isActive
                    ? "bg-primary text-primary-foreground font-semibold shadow-lg shadow-primary/20"
                    : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                )}>
                  <Icon className={cn("w-4 h-4 shrink-0", isActive ? "text-primary-foreground" : "text-muted-foreground group-hover:text-primary")} />
                  <span className="text-sm">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 pb-28 md:pb-0 overflow-x-hidden">
        <div className="max-w-5xl mx-auto w-full p-4 md:p-8">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 border-t border-border/50 bg-background/95 backdrop-blur-xl pb-safe z-50">
        <div className="flex items-center justify-around px-1 py-1 overflow-x-auto no-scrollbar">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className="flex-shrink-0">
                <div className="flex flex-col items-center p-1.5 min-w-[48px] cursor-pointer">
                  <div className={cn(
                    "p-1.5 rounded-full transition-all duration-300",
                    isActive ? "bg-primary text-primary-foreground shadow-md shadow-primary/30 -translate-y-0.5" : "text-muted-foreground"
                  )}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className={cn("text-[8px] mt-0.5 font-medium leading-none", isActive ? "text-primary" : "text-muted-foreground")}>
                    {item.label}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
