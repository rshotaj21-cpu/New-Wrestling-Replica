import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import Dashboard from "@/pages/Dashboard";
import Sessions from "@/pages/Sessions";
import Sparring from "@/pages/Sparring";
import StrengthConditioning from "@/pages/StrengthConditioning";
import Techniques from "@/pages/Techniques";
import CalendarView from "@/pages/CalendarView";
import Focus from "@/pages/Focus";
import Competitions from "@/pages/Competitions";
import OneOnOne from "@/pages/OneOnOne";
import Stats from "@/pages/Stats";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { refetchOnWindowFocus: false, retry: false }
  }
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/sessions" component={Sessions} />
        <Route path="/sparring" component={Sparring} />
        <Route path="/strength-conditioning" component={StrengthConditioning} />
        <Route path="/techniques" component={Techniques} />
        <Route path="/calendar" component={CalendarView} />
        <Route path="/focus" component={Focus} />
        <Route path="/competitions" component={Competitions} />
        <Route path="/one-on-one" component={OneOnOne} />
        <Route path="/stats" component={Stats} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <Router />
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
