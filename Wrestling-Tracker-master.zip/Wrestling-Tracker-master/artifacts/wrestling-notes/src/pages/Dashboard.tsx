import { useState } from "react";
import { useGetStats, useGetSessions, useGetCompetitions, useUpdateSettings } from "@workspace/api-client-react";
import { Activity, Trophy, Swords, Calendar as CalendarIcon, ArrowRight, Flame, Clock, Users, Star, Target, Dumbbell, ChevronDown, ChevronUp, Settings, BarChart3 } from "lucide-react";
import { Link } from "wouter";
import { formatDate } from "@/lib/utils";
import { motion } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";

const PLACEMENT_META: Record<string, { label: string; color: string; medal: string }> = {
  "1st":     { label: "1st Place", color: "text-yellow-400", medal: "🥇" },
  "2nd":     { label: "2nd Place", color: "text-slate-300",  medal: "🥈" },
  "3rd":     { label: "3rd Place", color: "text-amber-500",  medal: "🥉" },
  "4th-6th": { label: "4th–6th",  color: "text-muted-foreground", medal: "🏅" },
  "7th+":    { label: "7th+",     color: "text-muted-foreground", medal: "🏅" },
};

export default function Dashboard() {
  const { data: stats } = useGetStats();
  const { data: sessions } = useGetSessions();
  const { data: competitions } = useGetCompetitions();
  const [showTargetEdit, setShowTargetEdit] = useState(false);
  const [targetInput, setTargetInput] = useState("");
  const updateSettings = useUpdateSettings();
  const queryClient = useQueryClient();

  const recentSessions = sessions?.slice(0, 3) || [];
  const upcomingComps = competitions?.filter(c => c.status === 'upcoming').slice(0, 2) || [];
  const completedComps = competitions?.filter(c => c.status === 'completed' && c.placement) || [];

  const weeklyTarget = stats?.weeklySessionsTarget || 3;
  const yearTarget = weeklyTarget * 52;
  const yearDone = stats?.sessionsThisYear || 0;
  const yearProgress = Math.min(100, Math.round((yearDone / yearTarget) * 100));

  const medalCounts = completedComps.reduce((acc, c) => {
    if (c.placement && PLACEMENT_META[c.placement]) {
      acc[c.placement] = (acc[c.placement] || 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);

  const handleSaveTarget = () => {
    const val = parseInt(targetInput);
    if (val > 0) {
      updateSettings.mutate({ data: { weeklySessionsTarget: val } }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
          setShowTargetEdit(false);
        }
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-card border border-border/50"
      >
        <div className="absolute inset-0 z-0">
          <img src={`${import.meta.env.BASE_URL}images/hero-bg.png`} alt="" className="w-full h-full object-cover opacity-40 mix-blend-overlay" />
          <div className="absolute inset-0 bg-gradient-to-t from-card via-card/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-card via-card/50 to-transparent" />
        </div>
        <div className="relative z-10 p-6 md:p-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
          <div>
            <div className="flex items-center gap-2 text-primary font-bold tracking-wider uppercase text-sm mb-2">
              <Flame className="w-4 h-4" />
              {(stats?.currentStreak || 0) > 0
                ? `${stats?.currentStreak} week streak 🔥`
                : "Keep the streak alive"
              }
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-black text-white uppercase italic">
              Grind <span className="text-primary">Harder.</span>
            </h1>
            <p className="text-muted-foreground mt-2 max-w-md">
              {stats?.sessionsThisMonth || 0} sessions this month · {stats?.totalMatTimeHours || 0}h total mat time.
            </p>
          </div>
          <Link href="/sessions">
            <div className="px-6 py-3 bg-primary text-primary-foreground font-bold rounded-xl flex items-center gap-2 hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20 cursor-pointer">
              Log Session <ArrowRight className="w-5 h-5" />
            </div>
          </Link>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard title="Sessions (YTD)" value={yearDone} icon={Activity} color="text-primary" bg="bg-primary/10" />
        <StatCard title="Sparring Rounds" value={stats?.totalSparringRounds || 0} icon={Swords} color="text-green-400" bg="bg-green-400/10" />
        <StatCard title="Mat Time" value={`${stats?.totalMatTimeHours || 0}h`} icon={Clock} color="text-blue-400" bg="bg-blue-400/10" />
        <StatCard title="1-2-1 Sessions" value={stats?.oneOnOneCount || 0} icon={Users} color="text-purple-400" bg="bg-purple-400/10" />
      </div>

      {/* Annual Session Tracker */}
      <div className="bg-card border border-border/50 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            <span className="font-bold">Annual Session Target</span>
          </div>
          <button
            onClick={() => { setShowTargetEdit(!showTargetEdit); setTargetInput(String(weeklyTarget)); }}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded-lg hover:bg-white/5"
          >
            <Settings className="w-3 h-3" /> {showTargetEdit ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>

        {showTargetEdit && (
          <div className="flex items-center gap-3 mb-4 p-3 bg-secondary/30 rounded-xl">
            <span className="text-sm text-muted-foreground whitespace-nowrap">Sessions/week:</span>
            <input
              type="number" min="1" max="14"
              value={targetInput}
              onChange={e => setTargetInput(e.target.value)}
              className="w-20 bg-background border border-border rounded-lg px-3 py-1.5 text-sm font-bold text-center"
            />
            <button onClick={handleSaveTarget} className="px-3 py-1.5 bg-primary text-primary-foreground text-sm font-bold rounded-lg hover:bg-primary/90">Save</button>
          </div>
        )}

        <div className="flex items-end justify-between mb-2">
          <div>
            <span className="text-4xl font-display font-black text-primary">{yearDone}</span>
            <span className="text-xl font-bold text-muted-foreground">/{yearTarget}</span>
          </div>
          <span className="text-sm font-bold text-muted-foreground">{yearProgress}%</span>
        </div>
        <div className="w-full h-3 bg-secondary/50 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${yearProgress}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="h-full bg-primary rounded-full"
          />
        </div>
        <p className="text-xs text-muted-foreground mt-2">{weeklyTarget} sessions/week × 52 weeks = {yearTarget} target</p>
      </div>

      {/* Competition Record */}
      {(stats?.totalCompetitions || 0) > 0 && (
        <div className="bg-card border border-border/50 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-400" />
              <span className="font-bold">Competition Record</span>
            </div>
            <Link href="/competitions">
              <span className="text-xs text-primary hover:underline cursor-pointer">View All</span>
            </Link>
          </div>
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="text-center p-3 rounded-xl bg-green-400/10 border border-green-400/20">
              <div className="text-2xl font-display font-black text-green-400">{stats?.totalWins || 0}</div>
              <div className="text-[10px] font-bold uppercase text-green-400/80">Wins</div>
            </div>
            <div className="text-center p-3 rounded-xl bg-red-400/10 border border-red-400/20">
              <div className="text-2xl font-display font-black text-red-400">{stats?.totalLosses || 0}</div>
              <div className="text-[10px] font-bold uppercase text-red-400/80">Losses</div>
            </div>
            <div className="text-center p-3 rounded-xl bg-primary/10 border border-primary/20">
              <div className="text-2xl font-display font-black text-primary">{stats?.totalCompetitionMatches || (stats?.totalWins || 0) + (stats?.totalLosses || 0)}</div>
              <div className="text-[10px] font-bold uppercase text-primary/80">Matches</div>
            </div>
          </div>
          {Object.keys(medalCounts).length > 0 && (
            <div className="border-t border-border/30 pt-4">
              <p className="text-xs font-bold uppercase text-muted-foreground mb-3">Career Placements</p>
              <div className="flex flex-wrap gap-2">
                {Object.entries(medalCounts).map(([place, count]) => {
                  const meta = PLACEMENT_META[place];
                  return meta ? (
                    <div key={place} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-secondary/50 border border-border/50">
                      <span className="text-xl">{meta.medal}</span>
                      <div>
                        <div className={`text-sm font-bold ${meta.color}`}>{meta.label}</div>
                        <div className="text-xs text-muted-foreground">×{count}</div>
                      </div>
                    </div>
                  ) : null;
                })}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Recent Sessions */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-display font-bold">Recent Training</h2>
            <Link href="/sessions"><span className="text-sm text-primary hover:underline cursor-pointer">View All</span></Link>
          </div>
          {recentSessions.length === 0 ? (
            <div className="bg-card border border-border/50 rounded-2xl p-6 text-center text-muted-foreground text-sm">No sessions yet. Get on the mat!</div>
          ) : (
            <div className="space-y-2">
              {recentSessions.map(session => (
                <div key={session.id} className="bg-card border-l-4 border-l-blue-500 border border-border/50 rounded-xl p-4 flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-sm truncate">{session.title}</h3>
                    <p className="text-xs text-muted-foreground">{formatDate(session.date)} · {session.durationMinutes}min</p>
                  </div>
                  <div className="text-sm font-black text-yellow-400 shrink-0">{session.rating}/10</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Upcoming Comps */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-display font-bold">Next Up</h2>
            <Link href="/competitions"><span className="text-sm text-primary hover:underline cursor-pointer">View All</span></Link>
          </div>
          {upcomingComps.length === 0 ? (
            <div className="bg-card border border-border/50 rounded-2xl p-6 text-center text-muted-foreground text-sm">No upcoming competitions.</div>
          ) : (
            <div className="space-y-2">
              {upcomingComps.map(comp => {
                const daysUntil = Math.ceil((new Date(comp.date).getTime() - Date.now()) / 86400000);
                return (
                  <div key={comp.id} className="bg-card border border-primary/20 rounded-xl p-4 flex items-center gap-3">
                    <div className="text-center shrink-0 w-12">
                      <div className="text-2xl font-display font-black text-primary leading-none">{daysUntil}</div>
                      <div className="text-[9px] font-bold uppercase text-primary/70">days</div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-sm truncate">{comp.name}</h3>
                      <p className="text-xs text-muted-foreground">{formatDate(comp.date)}{comp.weightClassKg ? ` · ${comp.weightClassKg}kg` : ''}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Quick link to stats */}
      <Link href="/stats">
        <div className="bg-card border border-border/50 rounded-2xl p-4 flex items-center justify-between hover:border-primary/40 transition-colors cursor-pointer group">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-xl">
              <BarChart3 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <div className="font-bold text-sm">Full Performance Stats</div>
              <div className="text-xs text-muted-foreground">Techniques, competition analytics & training heatmap</div>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
        </div>
      </Link>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color, bg }: any) {
  return (
    <div className="bg-card border border-border/50 rounded-2xl p-4 flex flex-col justify-between hover:bg-white/[0.02] transition-colors">
      <div className="flex justify-between items-center mb-3">
        <span className="text-xs font-medium text-muted-foreground">{title}</span>
        <div className={`p-1.5 rounded-lg ${bg} ${color}`}><Icon className="w-4 h-4" /></div>
      </div>
      <div className="text-3xl font-display font-bold">{value}</div>
    </div>
  );
}
