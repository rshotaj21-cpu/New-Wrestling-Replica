import { useState } from "react";
import { useGetStrengthConditioningSessions, useCreateStrengthConditioningSession, useUpdateStrengthConditioningSession, useDeleteStrengthConditioningSession, StrengthConditioningSession } from "@workspace/api-client-react";
import { Dumbbell, Plus, Trash2, Edit2, Flame, Clock, Zap, ChevronDown, ChevronUp } from "lucide-react";
import { Dialog, Input, Textarea, Select, Button } from "@/components/ui/DialogComponents";
import { formatDate } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";

const TYPE_META: Record<string, { label: string; color: string; border: string; bg: string; badge: string }> = {
  strength:     { label: "Strength",     color: "text-blue-400",    border: "border-l-blue-500",    bg: "bg-blue-500/10",    badge: "bg-blue-500/15 text-blue-400 border-blue-500/30" },
  power:        { label: "Power",        color: "text-orange-400",  border: "border-l-orange-500",  bg: "bg-orange-500/10",  badge: "bg-orange-500/15 text-orange-400 border-orange-500/30" },
  conditioning: { label: "Conditioning", color: "text-red-400",     border: "border-l-red-500",     bg: "bg-red-500/10",     badge: "bg-red-500/15 text-red-400 border-red-500/30" },
  mixed:        { label: "Mixed",        color: "text-purple-400",  border: "border-l-purple-500",  bg: "bg-purple-500/10",  badge: "bg-purple-500/15 text-purple-400 border-purple-500/30" },
};

const FOCUS_PRESETS = [
  "Lower Body Strength", "Upper Body Pulling", "Upper Body Pushing",
  "Explosive Power", "Conditioning Intervals", "Full Body",
  "Posterior Chain", "Core & Stability", "Sprint Work", "Circuits",
];

function RpeBar({ value }: { value: number }) {
  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="text-xs font-bold uppercase text-muted-foreground flex items-center gap-1"><Flame className="w-3 h-3" /> Effort (RPE)</span>
        <span className={`text-sm font-black ${value >= 8 ? "text-red-400" : value >= 6 ? "text-orange-400" : "text-yellow-400"}`}>{value}/10</span>
      </div>
      <div className="h-3 bg-secondary/50 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${(value / 10) * 100}%` }}
          transition={{ duration: 0.6 }}
          className={`h-full rounded-full ${value >= 8 ? "bg-red-400" : value >= 6 ? "bg-orange-400" : "bg-yellow-400"}`}
        />
      </div>
    </div>
  );
}

export default function StrengthConditioning() {
  const { data: sessions, isLoading } = useGetStrengthConditioningSessions();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editSession, setEditSession] = useState<StrengthConditioningSession | null>(null);
  const [filterType, setFilterType] = useState<string>("all");

  const filtered = sessions?.filter(s => filterType === "all" || s.sessionType === filterType) || [];

  const totalMinutes = sessions?.reduce((acc, s) => acc + s.durationMinutes, 0) || 0;
  const totalHours = Math.round((totalMinutes / 60) * 10) / 10;
  const avgRpe = sessions?.length ? Math.round((sessions.reduce((a, s) => a + s.rpe, 0) / sessions.length) * 10) / 10 : 0;

  const typeCounts = (sessions || []).reduce((acc, s) => {
    acc[s.sessionType] = (acc[s.sessionType] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-black uppercase italic flex items-center gap-2">
            <Dumbbell className="w-8 h-8 text-blue-400" /> S&C Log
          </h1>
          <p className="text-muted-foreground text-sm">Strength, power and conditioning sessions.</p>
        </div>
        <Button onClick={() => setIsAddOpen(true)} className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white">
          <Plus className="w-5 h-5 mr-2" /> Log S&C
        </Button>
      </div>

      {sessions && sessions.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-3 text-center">
            <div className="text-2xl font-display font-black text-blue-400">{sessions.length}</div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mt-0.5">Sessions</div>
          </div>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-3 text-center">
            <div className="text-2xl font-display font-black text-blue-400">{totalHours}h</div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mt-0.5">Total Time</div>
          </div>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-3 text-center">
            <div className="text-2xl font-display font-black text-orange-400">{avgRpe}/10</div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mt-0.5">Avg RPE</div>
          </div>
        </div>
      )}

      {/* Type breakdown badges */}
      {sessions && sessions.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {Object.entries(typeCounts).map(([type, count]) => {
            const meta = TYPE_META[type] || TYPE_META.mixed;
            return (
              <div key={type} className={`px-3 py-1.5 rounded-full text-xs font-bold border ${meta.badge}`}>
                {meta.label}: {count}
              </div>
            );
          })}
        </div>
      )}

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap">
        {[
          { value: "all", label: "All" },
          { value: "strength", label: "💪 Strength" },
          { value: "power", label: "⚡ Power" },
          { value: "conditioning", label: "🔥 Conditioning" },
          { value: "mixed", label: "🌀 Mixed" },
        ].map(opt => (
          <button
            key={opt.value}
            onClick={() => setFilterType(opt.value)}
            className={`px-4 py-2 rounded-full text-sm font-bold transition-all ${filterType === opt.value ? "bg-foreground text-background" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-4">{[1,2,3].map(i => <div key={i} className="h-40 bg-card rounded-2xl animate-pulse" />)}</div>
      ) : (
        <div className="grid gap-4">
          <AnimatePresence>
            {filtered.map(session => (
              <SCCard key={session.id} session={session} onEdit={() => setEditSession(session)} />
            ))}
            {filtered.length === 0 && (
              <div className="text-center py-12 text-muted-foreground bg-card/50 rounded-3xl border border-dashed border-border/50">
                <Dumbbell className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p>No S&C sessions logged yet. Hit the gym!</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      )}

      <SCDialog open={isAddOpen} onOpenChange={setIsAddOpen} />
      {editSession && <SCDialog open={!!editSession} onOpenChange={() => setEditSession(null)} existing={editSession} />}
    </div>
  );
}

function SCCard({ session, onEdit }: { session: StrengthConditioningSession; onEdit: () => void }) {
  const deleteMutation = useDeleteStrengthConditioningSession();
  const queryClient = useQueryClient();
  const [expanded, setExpanded] = useState(false);
  const meta = TYPE_META[session.sessionType] || TYPE_META.mixed;

  const handleDelete = () => {
    if (confirm("Delete this session?")) {
      deleteMutation.mutate({ id: session.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/strength-conditioning"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        }
      });
    }
  };

  const hasExtra = session.exercises || session.conditioningType || session.wentWell || session.needsWork || session.notes;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={`bg-card border-l-4 ${meta.border} border border-border/50 rounded-2xl overflow-hidden group transition-all hover:border-white/20`}
    >
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase border ${meta.badge}`}>{meta.label}</span>
            </div>
            <h3 className="text-xl font-bold">{session.sessionFocus}</h3>
            <div className="flex flex-wrap gap-x-4 gap-y-0.5 text-sm text-muted-foreground mt-1">
              <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {formatDate(session.date)}</span>
              <span className="flex items-center gap-1"><Zap className="w-3.5 h-3.5" /> {session.durationMinutes} min</span>
            </div>
          </div>
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity ml-2">
            <button onClick={onEdit} className="p-2 text-muted-foreground hover:text-foreground hover:bg-white/5 rounded-lg">
              <Edit2 className="w-4 h-4" />
            </button>
            <button onClick={handleDelete} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        <RpeBar value={session.rpe} />

        {session.conditioningType && (
          <div className="mt-3 bg-red-500/5 border border-red-500/10 rounded-xl p-3">
            <div className="text-xs font-bold text-red-400 uppercase mb-1">Conditioning</div>
            <div className="text-sm font-bold">{session.conditioningType}</div>
            {session.conditioningDetails && <p className="text-xs text-muted-foreground mt-1">{session.conditioningDetails}</p>}
            {session.conditioningEffort && <p className="text-xs text-red-400 mt-1 font-bold">Effort: {session.conditioningEffort}/10</p>}
          </div>
        )}

        {hasExtra && (
          <button
            onClick={() => setExpanded(!expanded)}
            className="mt-3 flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            {expanded ? "Hide details" : "Show details"}
          </button>
        )}
      </div>

      {expanded && (
        <div className="px-5 pb-5 space-y-3 border-t border-border/30 pt-4">
          {session.exercises && (
            <div className="bg-secondary/30 rounded-xl p-3">
              <div className="text-xs font-bold uppercase text-muted-foreground mb-2">Exercises</div>
              <pre className="text-sm text-foreground whitespace-pre-wrap font-sans">{session.exercises}</pre>
            </div>
          )}
          <div className="grid sm:grid-cols-2 gap-3">
            {session.wentWell && (
              <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-xl p-3">
                <div className="text-xs font-bold text-emerald-400 uppercase mb-1">✓ Felt Strong</div>
                <p className="text-sm text-muted-foreground">{session.wentWell}</p>
              </div>
            )}
            {session.needsWork && (
              <div className="bg-orange-500/5 border border-orange-500/10 rounded-xl p-3">
                <div className="text-xs font-bold text-orange-400 uppercase mb-1">⚠ Needs Work</div>
                <p className="text-sm text-muted-foreground">{session.needsWork}</p>
              </div>
            )}
          </div>
          {session.notes && (
            <div className="bg-secondary/30 rounded-xl p-3">
              <div className="text-xs font-bold uppercase text-muted-foreground mb-1">Notes</div>
              <p className="text-sm text-muted-foreground">{session.notes}</p>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}

function SCDialog({ open, onOpenChange, existing }: { open: boolean; onOpenChange: (o: boolean) => void; existing?: StrengthConditioningSession }) {
  const [formData, setFormData] = useState({
    date: existing?.date || new Date().toISOString().split('T')[0],
    sessionType: (existing?.sessionType || "strength") as any,
    sessionFocus: existing?.sessionFocus || "",
    durationMinutes: existing?.durationMinutes || 60,
    rpe: existing?.rpe || 7,
    exercises: existing?.exercises || "",
    conditioningType: existing?.conditioningType || "",
    conditioningDetails: existing?.conditioningDetails || "",
    conditioningEffort: existing?.conditioningEffort || undefined,
    wentWell: existing?.wentWell || "",
    needsWork: existing?.needsWork || "",
    notes: existing?.notes || "",
  });

  const createMutation = useCreateStrengthConditioningSession();
  const updateMutation = useUpdateStrengthConditioningSession();
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/strength-conditioning"] });
    queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    onOpenChange(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      ...formData,
      exercises: formData.exercises || null,
      conditioningType: formData.conditioningType || null,
      conditioningDetails: formData.conditioningDetails || null,
      conditioningEffort: formData.conditioningEffort || null,
      wentWell: formData.wentWell || null,
      needsWork: formData.needsWork || null,
      notes: formData.notes || null,
    };
    if (existing) {
      updateMutation.mutate({ id: existing.id, data: payload }, { onSuccess: invalidate });
    } else {
      createMutation.mutate({ data: payload }, { onSuccess: invalidate });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;
  const showConditioning = formData.sessionType === "conditioning" || formData.sessionType === "mixed";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <div className="mb-4">
        <h2 className="text-2xl font-display font-bold">{existing ? "Edit S&C Session" : "Log S&C Session"}</h2>
        <p className="text-sm text-muted-foreground">Track your gym and conditioning work.</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Session Type</label>
            <Select
              value={formData.sessionType}
              onChange={v => setFormData({...formData, sessionType: v as any})}
              options={[
                {label: '💪 Strength', value: 'strength'},
                {label: '⚡ Power', value: 'power'},
                {label: '🔥 Conditioning', value: 'conditioning'},
                {label: '🌀 Mixed', value: 'mixed'},
              ]}
            />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Date</label>
            <Input type="date" required value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Duration (min)</label>
            <Input type="number" required min="1" value={formData.durationMinutes} onChange={e => setFormData({...formData, durationMinutes: parseInt(e.target.value)})} />
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Session Focus</label>
          <Input required value={formData.sessionFocus} onChange={e => setFormData({...formData, sessionFocus: e.target.value})} placeholder="e.g. Lower Body Strength, Explosive Power, Circuits..." />
          <div className="flex flex-wrap gap-1.5 mt-2">
            {FOCUS_PRESETS.map(p => (
              <button key={p} type="button" onClick={() => setFormData({...formData, sessionFocus: p})}
                className="px-2 py-1 text-[10px] font-bold bg-secondary/60 text-muted-foreground hover:bg-secondary hover:text-foreground rounded-full transition-colors">
                {p}
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex justify-between mb-1">
            <label className="text-xs font-bold text-muted-foreground uppercase">RPE (1–10)</label>
            <span className={`text-sm font-bold ${formData.rpe >= 8 ? "text-red-400" : formData.rpe >= 6 ? "text-orange-400" : "text-yellow-400"}`}>{formData.rpe}/10</span>
          </div>
          <input type="range" min="1" max="10" value={formData.rpe}
            onChange={e => setFormData({...formData, rpe: parseInt(e.target.value)})}
            className={`w-full ${formData.rpe >= 8 ? "accent-red-500" : formData.rpe >= 6 ? "accent-orange-500" : "accent-yellow-500"}`}
          />
          <div className="flex justify-between text-[10px] text-muted-foreground">
            <span>Easy</span><span>All out</span>
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Exercises (optional)</label>
          <Textarea
            value={formData.exercises}
            onChange={e => setFormData({...formData, exercises: e.target.value})}
            placeholder={"Squat: 4×5 @ 120kg\nDeadlift: 3×3 @ 150kg\nRDL: 3×8 @ 80kg"}
          />
        </div>

        {showConditioning && (
          <div className="space-y-3 border border-red-500/20 rounded-xl p-3 bg-red-500/5">
            <div className="text-xs font-bold text-red-400 uppercase">Conditioning Details</div>
            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Type</label>
              <Select
                value={formData.conditioningType}
                onChange={v => setFormData({...formData, conditioningType: v})}
                options={[
                  {label: '— None —', value: ''},
                  {label: 'Assault Bike', value: 'Assault Bike'},
                  {label: 'Rowing', value: 'Rowing'},
                  {label: 'Running', value: 'Running'},
                  {label: 'Circuits', value: 'Circuits'},
                  {label: 'Sled', value: 'Sled'},
                  {label: 'Wrestling Drills', value: 'Wrestling Drills'},
                  {label: 'Other', value: 'Other'},
                ]}
              />
            </div>
            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Intervals / Details</label>
              <Textarea value={formData.conditioningDetails} onChange={e => setFormData({...formData, conditioningDetails: e.target.value})} placeholder="20s hard / 10s easy × 8" />
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <label className="text-xs font-bold text-muted-foreground uppercase">Conditioning Effort (1–10)</label>
                <span className="text-sm font-bold text-red-400">{formData.conditioningEffort || "—"}</span>
              </div>
              <input type="range" min="1" max="10" value={formData.conditioningEffort || 7}
                onChange={e => setFormData({...formData, conditioningEffort: parseInt(e.target.value)})}
                className="w-full accent-red-500"
              />
            </div>
          </div>
        )}

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Felt Strong</label>
          <Textarea value={formData.wentWell} onChange={e => setFormData({...formData, wentWell: e.target.value})} placeholder="Hit a PR on squat, grip felt solid..." />
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Needs Work</label>
          <Textarea value={formData.needsWork} onChange={e => setFormData({...formData, needsWork: e.target.value})} placeholder="Hip mobility limiting depth, overhead tight..." />
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Notes</label>
          <Textarea value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} placeholder="Any other observations..." />
        </div>

        <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white" disabled={isPending}>
          {isPending ? "Saving..." : existing ? "Save Changes" : "Log Session"}
        </Button>
      </form>
    </Dialog>
  );
}
