import { useState } from "react";
import { useGetSessions, useCreateSession, useDeleteSession, useUpdateSession, Session } from "@workspace/api-client-react";
import { Plus, Trash2, Dumbbell, Star, Calendar as CalendarIcon, Clock, Edit2, Zap } from "lucide-react";
import { Dialog, Input, Textarea, Select, Button } from "@/components/ui/DialogComponents";
import { formatDate } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";

const SESSION_TYPE_META: Record<string, { label: string; color: string; border: string; badge: string }> = {
  training:         { label: "Training",        color: "border-l-blue-500",   border: "border-l-4", badge: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  drilling:         { label: "Drilling",         color: "border-l-indigo-500", border: "border-l-4", badge: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20" },
  competition_prep: { label: "Comp Prep",        color: "border-l-orange-500", border: "border-l-4", badge: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
  technique:        { label: "Technique",        color: "border-l-purple-500", border: "border-l-4", badge: "bg-purple-500/10 text-purple-400 border-purple-500/20" },
};

const RATING_COLORS = (r: number, max: number) => {
  const pct = r / max;
  if (pct >= 0.8) return "text-green-400";
  if (pct >= 0.5) return "text-yellow-400";
  return "text-orange-400";
};

export default function Sessions() {
  const { data: sessions, isLoading } = useGetSessions();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editSession, setEditSession] = useState<Session | null>(null);
  const [filterType, setFilterType] = useState<string>("all");

  const filtered = sessions?.filter(s => filterType === "all" || s.sessionType === filterType) || [];

  const totalMinutes = sessions?.reduce((acc, s) => acc + s.durationMinutes, 0) || 0;
  const totalHours = Math.round((totalMinutes / 60) * 10) / 10;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-black uppercase italic">Training Log</h1>
          <p className="text-muted-foreground text-sm">Track your progress and reflect on every session.</p>
        </div>
        <Button onClick={() => setIsAddOpen(true)} className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white">
          <Plus className="w-5 h-5 mr-2" /> Log Session
        </Button>
      </div>

      {/* Summary bar */}
      {sessions && sessions.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card border border-border/50 rounded-2xl p-3 text-center">
            <div className="text-2xl font-display font-black text-blue-400">{sessions.length}</div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mt-0.5">Total Sessions</div>
          </div>
          <div className="bg-card border border-border/50 rounded-2xl p-3 text-center">
            <div className="text-2xl font-display font-black text-primary">{totalHours}h</div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mt-0.5">Mat Time</div>
          </div>
          <div className="bg-card border border-border/50 rounded-2xl p-3 text-center">
            <div className="text-2xl font-display font-black text-yellow-400">
              {sessions.length > 0 ? Math.round(sessions.reduce((a,s) => a + s.rating, 0) / sessions.length * 10) / 10 : 0}/10
            </div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mt-0.5">Avg Rating</div>
          </div>
        </div>
      )}

      {/* Filter tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        {[
          { value: "all", label: "All" },
          { value: "training", label: "Training" },
          { value: "drilling", label: "Drilling" },
          { value: "competition_prep", label: "Comp Prep" },
          { value: "technique", label: "Technique" },
        ].map(opt => (
          <button
            key={opt.value}
            onClick={() => setFilterType(opt.value)}
            className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-bold transition-all ${filterType === opt.value ? "bg-foreground text-background" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="animate-pulse space-y-4">{[1,2,3].map(i => <div key={i} className="h-32 bg-card rounded-2xl" />)}</div>
      ) : (
        <div className="grid gap-4">
          <AnimatePresence>
            {filtered.map(session => (
              <SessionCard key={session.id} session={session} onEdit={() => setEditSession(session)} />
            ))}
            {filtered.length === 0 && (
              <div className="text-center py-12 text-muted-foreground bg-card/50 rounded-3xl border border-border/50 border-dashed">
                <Dumbbell className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p>No sessions logged yet. Get on the mat!</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      )}

      <SessionDialog open={isAddOpen} onOpenChange={setIsAddOpen} />
      {editSession && <SessionDialog open={!!editSession} onOpenChange={() => setEditSession(null)} existing={editSession} />}
    </div>
  );
}

function SessionCard({ session, onEdit }: { session: Session; onEdit: () => void }) {
  const deleteMutation = useDeleteSession();
  const queryClient = useQueryClient();
  const [expanded, setExpanded] = useState(false);
  const meta = SESSION_TYPE_META[session.sessionType] || SESSION_TYPE_META.training;

  const handleDelete = () => {
    if (confirm("Delete this session?")) {
      deleteMutation.mutate({ id: session.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        }
      });
    }
  };

  const ratingPct = Math.round((session.rating / 10) * 100);
  const ratingColor = RATING_COLORS(session.rating, 10);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={`bg-card border border-border/50 rounded-2xl overflow-hidden group hover:border-white/20 transition-all ${meta.border} ${meta.color}`}
    >
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase border ${meta.badge}`}>
                {meta.label}
              </span>
            </div>
            <h3 className="text-xl font-bold">{session.title}</h3>
          </div>
          <div className="flex gap-1 ml-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button onClick={onEdit} className="p-2 text-muted-foreground hover:text-foreground hover:bg-white/5 rounded-lg">
              <Edit2 className="w-4 h-4" />
            </button>
            <button onClick={handleDelete} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground mb-4">
          <span className="flex items-center gap-1.5"><CalendarIcon className="w-4 h-4" /> {formatDate(session.date)}</span>
          <span className="flex items-center gap-1.5"><Clock className="w-4 h-4" /> {session.durationMinutes} min</span>
        </div>

        {/* Rating bar */}
        <div className="mb-3">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs font-bold uppercase text-muted-foreground flex items-center gap-1">
              <Star className="w-3 h-3" /> Session Rating
            </span>
            <span className={`text-sm font-black ${ratingColor}`}>{session.rating}/10</span>
          </div>
          <div className="h-2 bg-secondary/50 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${ratingPct}%` }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className={`h-full rounded-full ${session.rating >= 8 ? "bg-green-400" : session.rating >= 5 ? "bg-yellow-400" : "bg-orange-400"}`}
            />
          </div>
        </div>

        {(session.wentWell || session.needsWork || session.notes) && (
          <button
            onClick={() => setExpanded(!expanded)}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            {expanded ? "▲ Hide details" : "▼ Show details"}
          </button>
        )}
      </div>

      {expanded && (
        <div className="px-5 pb-5 grid sm:grid-cols-2 gap-3 border-t border-border/30 pt-4">
          {session.wentWell && (
            <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-xl p-3">
              <div className="text-xs font-bold text-emerald-400 uppercase mb-1">✓ Went Well</div>
              <p className="text-sm text-muted-foreground">{session.wentWell}</p>
            </div>
          )}
          {session.needsWork && (
            <div className="bg-orange-500/5 border border-orange-500/10 rounded-xl p-3">
              <div className="text-xs font-bold text-orange-400 uppercase mb-1">⚠ Needs Work</div>
              <p className="text-sm text-muted-foreground">{session.needsWork}</p>
            </div>
          )}
          {session.notes && (
            <div className="sm:col-span-2 bg-secondary/30 rounded-xl p-3">
              <div className="text-xs font-bold text-muted-foreground uppercase mb-1">Notes</div>
              <p className="text-sm text-muted-foreground">{session.notes}</p>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}

function SessionDialog({ open, onOpenChange, existing }: { open: boolean; onOpenChange: (o: boolean) => void; existing?: Session }) {
  const [formData, setFormData] = useState({
    title: existing?.title || "",
    date: existing?.date || new Date().toISOString().split('T')[0],
    durationMinutes: existing?.durationMinutes || 90,
    rating: existing?.rating || 7,
    sessionType: (existing?.sessionType || "training") as any,
    wentWell: existing?.wentWell || "",
    needsWork: existing?.needsWork || "",
    notes: existing?.notes || "",
  });

  const createMutation = useCreateSession();
  const updateMutation = useUpdateSession();
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
    queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    onOpenChange(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (existing) {
      updateMutation.mutate({ id: existing.id, data: formData }, { onSuccess: invalidate });
    } else {
      createMutation.mutate({ data: formData }, { onSuccess: invalidate });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <div className="mb-4">
        <h2 className="text-2xl font-display font-bold">{existing ? "Edit Session" : "Log Session"}</h2>
        <p className="text-sm text-muted-foreground">Record your training details.</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Session Title</label>
          <Input required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="e.g. Open Mat, Takedown Drills, Comp Prep" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Date</label>
            <Input type="date" required value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Duration (min)</label>
            <Input type="number" required value={formData.durationMinutes} onChange={e => setFormData({...formData, durationMinutes: parseInt(e.target.value)})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Session Type</label>
            <Select
              value={formData.sessionType}
              onChange={v => setFormData({...formData, sessionType: v as any})}
              options={[
                {label: '🔵 Training', value: 'training'},
                {label: '🟣 Drilling', value: 'drilling'},
                {label: '🟠 Comp Prep', value: 'competition_prep'},
                {label: '🟣 Technique', value: 'technique'},
              ]}
            />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Session Rating (1–10)</label>
            <Select
              value={formData.rating.toString()}
              onChange={v => setFormData({...formData, rating: parseInt(v)})}
              options={Array.from({length: 10}, (_, i) => ({ label: `${i+1}/10`, value: String(i+1) }))}
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">What went well?</label>
          <Textarea value={formData.wentWell} onChange={e => setFormData({...formData, wentWell: e.target.value})} placeholder="Techniques that clicked, conditioning felt strong..." />
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">What needs work?</label>
          <Textarea value={formData.needsWork} onChange={e => setFormData({...formData, needsWork: e.target.value})} placeholder="Got stuck on bottom, finish pressure needs work..." />
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Notes</label>
          <Textarea value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} placeholder="Additional notes, techniques drilled, partner observations..." />
        </div>

        <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white" disabled={isPending}>
          {isPending ? "Saving..." : existing ? "Save Changes" : "Log Session"}
        </Button>
      </form>
    </Dialog>
  );
}
