import { useState, useMemo } from "react";
import { useGetSessions, useGetSparringSessions, useGetCompetitions, useGetOneOnOneSessions } from "@workspace/api-client-react";
import {
  format, startOfMonth, endOfMonth, eachDayOfInterval,
  isToday, isSameDay, subMonths, addMonths, getYear, setYear, setMonth, addYears, subYears, eachMonthOfInterval, startOfYear, endOfYear
} from "date-fns";
import { ChevronLeft, ChevronRight, Dumbbell, Swords, Trophy, Users, Filter, CheckCircle2, CalendarDays, LayoutGrid } from "lucide-react";

type FilterType = "all" | "training" | "sparring" | "competition" | "one_on_one";
type ViewMode = "month" | "year";

const FILTER_OPTIONS: { value: FilterType; label: string; bg: string; border: string; text: string; dotColor: string; icon: any }[] = [
  { value: "all",         label: "All",          bg: "bg-primary",    border: "border-primary",    text: "text-primary-foreground", dotColor: "bg-primary",    icon: Filter },
  { value: "training",    label: "Training",     bg: "bg-primary",    border: "border-primary",    text: "text-white",              dotColor: "bg-primary",    icon: Dumbbell },
  { value: "sparring",    label: "Sparring",     bg: "bg-green-500",  border: "border-green-500",  text: "text-white",              dotColor: "bg-green-500",  icon: Swords },
  { value: "competition", label: "Competitions", bg: "bg-yellow-400", border: "border-yellow-400", text: "text-black",              dotColor: "bg-yellow-400", icon: Trophy },
  { value: "one_on_one",  label: "1-2-1",        bg: "bg-purple-500", border: "border-purple-500", text: "text-white",              dotColor: "bg-purple-500", icon: Users },
];

const TYPE_COLORS: Record<FilterType, { cell: string; dot: string; text: string }> = {
  all:         { cell: "bg-primary/80",    dot: "bg-primary",    text: "text-white" },
  training:    { cell: "bg-primary/80",    dot: "bg-primary",    text: "text-white" },
  sparring:    { cell: "bg-green-500/80",  dot: "bg-green-500",  text: "text-white" },
  competition: { cell: "bg-yellow-400/90", dot: "bg-yellow-400", text: "text-black" },
  one_on_one:  { cell: "bg-purple-500/80", dot: "bg-purple-500", text: "text-white" },
};

export default function CalendarView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [activeFilter, setActiveFilter] = useState<FilterType>("all");
  const [viewMode, setViewMode] = useState<ViewMode>("month");

  // Fetch all data (no month filter for year view)
  const { data: allSessions } = useGetSessions();
  const { data: sparringSessions } = useGetSparringSessions();
  const { data: competitions } = useGetCompetitions();
  const { data: oneOnOnes } = useGetOneOnOneSessions();

  // Build a fast lookup: "yyyy-MM-dd" -> events[]
  const eventsByDate = useMemo(() => {
    const map = new Map<string, { type: FilterType; label: string }[]>();

    const add = (dateStr: string, type: FilterType, label: string) => {
      const key = dateStr;
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push({ type, label });
    };

    allSessions?.forEach(s => add(s.date, "training", s.title));
    sparringSessions?.forEach(s => add(s.date, "sparring", `${s.rounds} rounds`));
    competitions?.forEach(c => add(c.date, "competition", c.name));
    oneOnOnes?.forEach(o => add(o.date, "one_on_one", `1-2-1 w/ ${o.coachName}`));

    return map;
  }, [allSessions, sparringSessions, competitions, oneOnOnes]);

  const getEventsForDay = (day: Date): { type: FilterType; label: string }[] => {
    const key = format(day, "yyyy-MM-dd");
    const all = eventsByDate.get(key) || [];
    if (activeFilter === "all") return all;
    return all.filter(e => e.type === activeFilter);
  };

  // Monthly view helpers
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const startDayOfWeek = monthStart.getDay();
  const blanks = Array(startDayOfWeek).fill(null);

  // Yearly view helpers
  const yearStart = startOfYear(currentDate);
  const yearEnd = endOfYear(currentDate);
  const monthsInYear = eachMonthOfInterval({ start: yearStart, end: yearEnd });

  // Monthly summary counts
  const curMonthStr = format(currentDate, "yyyy-MM");
  const monthTraining = allSessions?.filter(s => s.date.startsWith(curMonthStr)).length || 0;
  const monthSparring = sparringSessions?.filter(s => s.date.startsWith(curMonthStr)).length || 0;
  const monthComps = competitions?.filter(c => c.date.startsWith(curMonthStr)).length || 0;
  const monthOOO = oneOnOnes?.filter(o => o.date.startsWith(curMonthStr)).length || 0;

  // Yearly summary
  const yearStr = String(getYear(currentDate));
  const yearTraining = allSessions?.filter(s => s.date.startsWith(yearStr)).length || 0;
  const yearSparring = sparringSessions?.filter(s => s.date.startsWith(yearStr)).length || 0;
  const yearComps = competitions?.filter(c => c.date.startsWith(yearStr)).length || 0;
  const yearOOO = oneOnOnes?.filter(o => o.date.startsWith(yearStr)).length || 0;

  const primaryTypeForDay = (events: { type: FilterType }[]): FilterType | null => {
    if (events.length === 0) return null;
    const priority: FilterType[] = ["competition", "one_on_one", "sparring", "training"];
    for (const p of priority) {
      if (events.find(e => e.type === p)) return p;
    }
    return events[0].type;
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-black uppercase italic">Calendar</h1>
          <p className="text-muted-foreground text-sm">Your full training history.</p>
        </div>

        <div className="flex items-center gap-2">
          {/* View toggle */}
          <div className="flex rounded-xl border border-border/50 overflow-hidden">
            <button
              onClick={() => setViewMode("month")}
              className={`flex items-center gap-1.5 px-3 py-2 text-sm font-bold transition-colors ${viewMode === "month" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-white/5"}`}
            >
              <CalendarDays className="w-4 h-4" /> Month
            </button>
            <button
              onClick={() => setViewMode("year")}
              className={`flex items-center gap-1.5 px-3 py-2 text-sm font-bold transition-colors ${viewMode === "year" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-white/5"}`}
            >
              <LayoutGrid className="w-4 h-4" /> Year
            </button>
          </div>

          {/* Nav */}
          <button
            onClick={() => viewMode === "month" ? setCurrentDate(subMonths(currentDate, 1)) : setCurrentDate(subYears(currentDate, 1))}
            className="p-2 bg-card border border-border/50 rounded-xl hover:bg-white/5 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="font-display font-bold text-lg min-w-[130px] text-center">
            {viewMode === "month" ? format(currentDate, 'MMMM yyyy') : getYear(currentDate)}
          </span>
          <button
            onClick={() => viewMode === "month" ? setCurrentDate(addMonths(currentDate, 1)) : setCurrentDate(addYears(currentDate, 1))}
            className="p-2 bg-card border border-border/50 rounded-xl hover:bg-white/5 transition-colors"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
      {/* Filter Pills */}
      <div className="flex gap-2 flex-wrap">
        {FILTER_OPTIONS.map(opt => {
          const Icon = opt.icon;
          const isActive = activeFilter === opt.value;
          return (
            <button
              key={opt.value}
              onClick={() => setActiveFilter(opt.value)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-bold border transition-all ${
                isActive
                  ? `${opt.bg} ${opt.text} ${opt.border} shadow-lg`
                  : "bg-card border-border/50 text-muted-foreground hover:border-white/20 hover:text-foreground"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {opt.label}
            </button>
          );
        })}
      </div>
      {/* ─── MONTH VIEW ─── */}
      {viewMode === "month" && (
        <>
          <div className="bg-card border border-border/50 rounded-3xl p-4 md:p-6">
            {/* Day headers */}
            <div className="grid grid-cols-7 mb-3">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
                <div key={d} className="text-center text-[11px] font-bold text-muted-foreground uppercase py-2">{d}</div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-1.5">
              {blanks.map((_, i) => <div key={`b-${i}`} className="aspect-square rounded-xl" />)}

              {daysInMonth.map(day => {
                const events = getEventsForDay(day);
                const hasEvents = events.length > 0;
                const isTodayDate = isToday(day);
                const uniqueTypes = [...new Set(events.map(e => e.type))];
                const primaryType = primaryTypeForDay(events);
                const colors = primaryType ? TYPE_COLORS[primaryType] : null;
                const tooltip = events.map(e => e.label).join(' · ');

                return (
                  <div
                    key={day.toString()}
                    title={tooltip}
                    className={`
                      aspect-square rounded-xl flex flex-col items-center justify-between p-1.5 transition-all relative overflow-hidden
                      ${hasEvents
                        ? `${colors!.cell} cursor-default shadow-md`
                        : isTodayDate
                          ? "bg-secondary/30 border-2 border-primary"
                          : "bg-secondary/10 border border-transparent"
                      }
                      ${isTodayDate && hasEvents ? "ring-2 ring-white/40 ring-offset-1 ring-offset-background" : ""}
                    `}
                  >
                    {/* Date number */}
                    <span className={`text-xs font-black self-start leading-none ${
                      hasEvents ? colors!.text : isTodayDate ? "text-primary" : "text-muted-foreground/50"
                    }`}>
                      {format(day, 'd')}
                    </span>
                    {/* Checkmark for done days */}
                    {hasEvents && (
                      <CheckCircle2 className={`w-4 h-4 md:w-5 md:h-5 ${colors!.text} opacity-90`} strokeWidth={2.5} />
                    )}
                    {/* Multi-type dots at bottom */}
                    {hasEvents && uniqueTypes.length > 1 && (
                      <div className="flex gap-0.5 justify-center">
                        {uniqueTypes.slice(0, 4).map((type, i) => (
                          <div key={i} className="w-1.5 h-1.5 rounded-full bg-white/60 border-t-[2px] border-r-[2px] border-b-[2px] border-l-[2px] text-[#fafafa] rounded-tl-[37282705px] rounded-tr-[37282705px] rounded-br-[37282705px] rounded-bl-[37282705px]" />
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-x-4 gap-y-2">
            {FILTER_OPTIONS.filter(f => f.value !== 'all').map(opt => (
              <div key={opt.value} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <div className={`w-3 h-3 rounded-full ${opt.dotColor}`} />
                {opt.label}
              </div>
            ))}
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <CheckCircle2 className="w-3 h-3 text-foreground" />
              = Session done
            </div>
          </div>

          {/* Monthly Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <SummaryCard label="Training" value={monthTraining} color="text-primary" bg="bg-primary/10 border-primary/20" />
            <SummaryCard label="Sparring" value={monthSparring} color="text-green-400" bg="bg-green-400/10 border-green-400/20" />
            <SummaryCard label="Competitions" value={monthComps} color="text-yellow-400" bg="bg-yellow-400/10 border-yellow-400/20" />
            <SummaryCard label="1-2-1 Sessions" value={monthOOO} color="text-purple-400" bg="bg-purple-400/10 border-purple-400/20" />
          </div>
        </>
      )}
      {/* ─── YEAR VIEW ─── */}
      {viewMode === "year" && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {monthsInYear.map(monthDate => {
              const mStart = startOfMonth(monthDate);
              const mEnd = endOfMonth(monthDate);
              const days = eachDayOfInterval({ start: mStart, end: mEnd });
              const mBlanks = Array(mStart.getDay()).fill(null);
              const isCurrentMonth = format(monthDate, "yyyy-MM") === format(new Date(), "yyyy-MM");

              return (
                <div
                  key={monthDate.toString()}
                  onClick={() => { setCurrentDate(monthDate); setViewMode("month"); }}
                  className={`bg-card border rounded-2xl p-3 cursor-pointer hover:border-primary/50 transition-all hover:bg-white/[0.02] ${
                    isCurrentMonth ? "border-primary/40 shadow-lg shadow-primary/5" : "border-border/50"
                  }`}
                >
                  <h3 className={`text-xs font-bold uppercase tracking-wide mb-2 ${isCurrentMonth ? "text-primary" : "text-muted-foreground"}`}>
                    {format(monthDate, "MMMM")}
                  </h3>

                  {/* Mini day headers */}
                  <div className="grid grid-cols-7 gap-px mb-1">
                    {['S','M','T','W','T','F','S'].map((d, i) => (
                      <div key={i} className="text-center text-[8px] font-bold text-muted-foreground/50">{d}</div>
                    ))}
                  </div>

                  {/* Mini day grid */}
                  <div className="grid grid-cols-7 gap-px">
                    {mBlanks.map((_, i) => <div key={`mb-${i}`} className="aspect-square" />)}
                    {days.map(day => {
                      const events = getEventsForDay(day);
                      const hasEvents = events.length > 0;
                      const isTodayDate = isToday(day);
                      const primaryType = primaryTypeForDay(events);
                      const colors = primaryType ? TYPE_COLORS[primaryType] : null;

                      return (
                        <div
                          key={day.toString()}
                          title={format(day, 'd')}
                          className={`aspect-square rounded-sm flex items-center justify-center transition-all
                            ${hasEvents
                              ? `${colors!.cell} shadow-sm`
                              : isTodayDate
                                ? "ring-1 ring-primary bg-primary/10"
                                : "bg-secondary/10"
                            }
                          `}
                        >
                          {isTodayDate && !hasEvents && (
                            <div className="w-1 h-1 rounded-full bg-primary" />
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Month activity count */}
                  {(() => {
                    const mStr = format(monthDate, "yyyy-MM");
                    const count = (allSessions?.filter(s => s.date.startsWith(mStr)).length || 0)
                      + (sparringSessions?.filter(s => s.date.startsWith(mStr)).length || 0)
                      + (competitions?.filter(c => c.date.startsWith(mStr)).length || 0)
                      + (oneOnOnes?.filter(o => o.date.startsWith(mStr)).length || 0);
                    return count > 0 ? (
                      <div className="mt-2 text-[10px] font-bold text-muted-foreground text-center">{count} {count === 1 ? 'session' : 'sessions'}</div>
                    ) : (
                      <div className="mt-2 text-[10px] text-muted-foreground/30 text-center">—</div>
                    );
                  })()}
                </div>
              );
            })}
          </div>

          {/* Yearly Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <SummaryCard label="Training" value={yearTraining} color="text-primary" bg="bg-primary/10 border-primary/20" suffix="sessions" />
            <SummaryCard label="Sparring" value={yearSparring} color="text-green-400" bg="bg-green-400/10 border-green-400/20" suffix="sessions" />
            <SummaryCard label="Competitions" value={yearComps} color="text-yellow-400" bg="bg-yellow-400/10 border-yellow-400/20" suffix="events" />
            <SummaryCard label="1-2-1 Sessions" value={yearOOO} color="text-purple-400" bg="bg-purple-400/10 border-purple-400/20" suffix="sessions" />
          </div>
        </>
      )}
    </div>
  );
}

function SummaryCard({ label, value, color, bg, suffix }: { label: string; value: number; color: string; bg: string; suffix?: string }) {
  return (
    <div className={`rounded-2xl p-4 border text-center ${bg}`}>
      <div className={`text-3xl font-display font-black ${color}`}>{value}</div>
      <div className="text-xs font-bold uppercase text-muted-foreground mt-1">{label}</div>
      {suffix && <div className="text-[10px] text-muted-foreground/60">{suffix} this year</div>}
    </div>
  );
}
