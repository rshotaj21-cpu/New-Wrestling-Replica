import { useState } from "react";
import { useGetCompetitions, useCreateCompetition, useDeleteCompetition, useUpdateCompetition, Competition } from "@workspace/api-client-react";
import { Trophy, Plus, MapPin, Scale, Trash2, Swords, TrendingUp, Edit2, Check, X } from "lucide-react";
import { Dialog, Input, Select, Button, Textarea } from "@/components/ui/DialogComponents";
import { formatDate } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";

export default function Competitions() {
  const { data: competitions, isLoading } = useGetCompetitions();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editComp, setEditComp] = useState<Competition | null>(null);

  const upcoming = competitions?.filter(c => c.status === 'upcoming').sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()) || [];
  const past = competitions?.filter(c => c.status !== 'upcoming').sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()) || [];

  const totalWins = competitions?.reduce((acc, c) => acc + (c.wins || 0), 0) || 0;
  const totalLosses = competitions?.reduce((acc, c) => acc + (c.losses || 0), 0) || 0;
  const totalMatches = competitions?.reduce((acc, c) => acc + (c.totalMatches || 0), 0) || 0;

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-black uppercase italic">Competitions</h1>
          <p className="text-muted-foreground text-sm">Where the work pays off.</p>
        </div>
        <Button onClick={() => setIsAddOpen(true)} className="w-full sm:w-auto">
          <Plus className="w-5 h-5 mr-2" /> Add Event
        </Button>
      </div>

      {/* Overall Record Banner */}
      {(totalMatches > 0 || totalWins > 0 || totalLosses > 0) && (
        <div className="grid grid-cols-3 gap-4">
          <RecordStat label="Total Wins" value={totalWins} color="text-green-400" bg="bg-green-400/10 border-green-400/20" icon="W" />
          <RecordStat label="Total Losses" value={totalLosses} color="text-red-400" bg="bg-red-400/10 border-red-400/20" icon="L" />
          <RecordStat label="Total Matches" value={totalMatches || (totalWins + totalLosses)} color="text-primary" bg="bg-primary/10 border-primary/20" icon={<Swords className="w-5 h-5" />} />
        </div>
      )}

      {upcoming.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-display font-bold flex items-center gap-2"><Trophy className="w-5 h-5 text-primary" /> Upcoming</h2>
          <div className="grid gap-4">
            {upcoming.map(comp => <CompCard key={comp.id} comp={comp} isUpcoming onEdit={setEditComp} />)}
          </div>
        </div>
      )}

      {past.length > 0 && (
        <div className="space-y-4 mt-8">
          <h2 className="text-xl font-display font-bold text-muted-foreground">History</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {past.map(comp => <CompCard key={comp.id} comp={comp} onEdit={setEditComp} />)}
          </div>
        </div>
      )}

      {!isLoading && competitions?.length === 0 && (
        <div className="text-center py-20 text-muted-foreground bg-card/50 rounded-3xl border border-border/50 border-dashed">
          <Trophy className="w-16 h-16 mx-auto mb-4 opacity-20" />
          <p className="text-lg">No competitions scheduled.</p>
          <Button variant="outline" className="mt-4" onClick={() => setIsAddOpen(true)}>Add your first event</Button>
        </div>
      )}

      <CompDialog open={isAddOpen} onOpenChange={setIsAddOpen} />
      {editComp && <CompDialog open={!!editComp} onOpenChange={() => setEditComp(null)} existing={editComp} />}
    </div>
  );
}

function RecordStat({ label, value, color, bg, icon }: { label: string; value: number; color: string; bg: string; icon: any }) {
  return (
    <div className={`rounded-2xl p-4 border text-center ${bg}`}>
      <div className={`text-3xl font-display font-black ${color}`}>{value}</div>
      <div className="text-xs font-bold uppercase text-muted-foreground mt-1">{label}</div>
    </div>
  );
}

function CompCard({ comp, isUpcoming = false, onEdit }: { comp: Competition; isUpcoming?: boolean; onEdit: (c: Competition) => void }) {
  const deleteMutation = useDeleteCompetition();
  const queryClient = useQueryClient();

  const daysUntil = isUpcoming ? Math.ceil((new Date(comp.date).getTime() - new Date().getTime()) / (1000 * 3600 * 24)) : null;
  const winRate = comp.totalMatches ? Math.round(((comp.wins || 0) / comp.totalMatches) * 100) : null;

  const handleDelete = () => {
    if(confirm("Remove this competition?")) {
      deleteMutation.mutate({ id: comp.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/competitions"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        }
      });
    }
  };

  return (
    <motion.div
      layout
      className={`relative overflow-hidden rounded-2xl p-6 border transition-all group ${
        isUpcoming
          ? 'bg-card border-primary/30 shadow-xl shadow-primary/5'
          : 'bg-card/50 border-border/50 hover:bg-card'
      }`}
    >
      {isUpcoming && <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2" />}

      <div className="relative z-10">
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            <div className="flex flex-wrap gap-2 mb-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-primary/20 text-primary border border-primary/20">
                {comp.style.replace('_', ' ')}
              </span>
              {comp.status !== 'upcoming' && (
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border ${comp.status === 'completed' ? 'bg-accent/20 text-accent border-accent/20' : 'bg-destructive/20 text-destructive border-destructive/20'}`}>
                  {comp.status}
                </span>
              )}
            </div>
            <h3 className="text-2xl font-bold text-foreground">{comp.name}</h3>
          </div>

          {isUpcoming && daysUntil !== null && (
            <div className="text-right ml-4">
              <div className="text-3xl font-display font-black text-primary leading-none">{daysUntil}</div>
              <div className="text-[10px] font-bold uppercase text-primary/80">Days Out</div>
            </div>
          )}

          <div className="flex gap-1 ml-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button onClick={() => onEdit(comp)} className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors">
              <Edit2 className="w-4 h-4" />
            </button>
            <button onClick={handleDelete} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-4">
          <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4" /> {comp.location || 'TBD'}</span>
          <span className="flex items-center gap-1.5"><Scale className="w-4 h-4" /> {comp.weightClassKg ? `${comp.weightClassKg} kg` : 'TBD'}</span>
          <span>{formatDate(comp.date)}</span>
        </div>

        {/* Wins / Losses / Matches */}
        {comp.status === 'completed' && (comp.wins !== null || comp.losses !== null || comp.totalMatches !== null) && (
          <div className="flex gap-3 mb-4">
            {comp.wins !== null && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-green-400/10 border border-green-400/20">
                <Check className="w-4 h-4 text-green-400" />
                <span className="font-bold text-green-400">{comp.wins}W</span>
              </div>
            )}
            {comp.losses !== null && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-400/10 border border-red-400/20">
                <X className="w-4 h-4 text-red-400" />
                <span className="font-bold text-red-400">{comp.losses}L</span>
              </div>
            )}
            {winRate !== null && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary/10 border border-primary/20">
                <TrendingUp className="w-4 h-4 text-primary" />
                <span className="font-bold text-primary">{winRate}%</span>
              </div>
            )}
          </div>
        )}

        {comp.placement && (
          <div className="mb-3">
            {comp.placement === '1st' && <span className="text-2xl font-display font-black text-yellow-400">🥇 1st Place — Gold</span>}
            {comp.placement === '2nd' && <span className="text-2xl font-display font-black text-slate-300">🥈 2nd Place — Silver</span>}
            {comp.placement === '3rd' && <span className="text-2xl font-display font-black text-amber-500">🥉 3rd Place — Bronze</span>}
            {comp.placement === '4th-6th' && <span className="text-xl font-display font-black text-muted-foreground">🏅 4th–6th Place</span>}
            {comp.placement === '7th+' && <span className="text-xl font-display font-black text-muted-foreground">🏅 7th Place or above</span>}
          </div>
        )}

        {comp.result && (
          <div className="mt-2 p-3 bg-accent/10 border border-accent/20 rounded-xl">
            <div className="text-xs font-bold text-accent uppercase mb-1">Result Notes</div>
            <p className="text-sm font-medium text-foreground">{comp.result}</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function CompDialog({ open, onOpenChange, existing }: { open: boolean; onOpenChange: (o: boolean) => void; existing?: Competition }) {
  const [formData, setFormData] = useState({
    name: existing?.name || "",
    date: existing?.date || new Date().toISOString().split('T')[0],
    location: existing?.location || "",
    weightClassKg: existing?.weightClassKg || 74,
    style: (existing?.style || "freestyle") as any,
    status: (existing?.status || "upcoming") as any,
    wins: existing?.wins ?? null as number | null,
    losses: existing?.losses ?? null as number | null,
    totalMatches: existing?.totalMatches ?? null as number | null,
    placement: existing?.placement || "" as string | null,
    result: existing?.result || "",
    notes: existing?.notes || ""
  });

  const createMutation = useCreateCompetition();
  const updateMutation = useUpdateCompetition();
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/competitions"] });
    queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    onOpenChange(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      ...formData,
      weightClassKg: formData.weightClassKg || null,
      wins: formData.wins !== null && formData.wins !== undefined ? Number(formData.wins) : null,
      losses: formData.losses !== null && formData.losses !== undefined ? Number(formData.losses) : null,
      totalMatches: formData.totalMatches !== null && formData.totalMatches !== undefined ? Number(formData.totalMatches) : null,
      placement: formData.placement || null,
    };
    if (existing) {
      updateMutation.mutate({ id: existing.id, data: payload }, { onSuccess: invalidate });
    } else {
      createMutation.mutate({ data: payload }, { onSuccess: invalidate });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <div className="mb-4">
        <h2 className="text-2xl font-display font-bold">{existing ? "Edit Competition" : "Add Competition"}</h2>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Event Name</label>
          <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. State Championships" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Date</label>
            <Input type="date" required value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Weight Class (kg)</label>
            <Input type="number" value={formData.weightClassKg || ''} onChange={e => setFormData({...formData, weightClassKg: parseFloat(e.target.value)})} placeholder="e.g. 74" />
          </div>
          <div className="col-span-2">
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Location</label>
            <Input value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} placeholder="City, State" />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Style</label>
            <Select
              value={formData.style}
              onChange={v => setFormData({...formData, style: v as any})}
              options={[
                {label: 'Freestyle', value: 'freestyle'},
                {label: 'Greco-Roman', value: 'greco_roman'},
              ]}
            />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Status</label>
            <Select
              value={formData.status}
              onChange={v => setFormData({...formData, status: v as any})}
              options={[
                {label: 'Upcoming', value: 'upcoming'},
                {label: 'Completed', value: 'completed'},
                {label: 'Cancelled', value: 'cancelled'},
              ]}
            />
          </div>
        </div>

        {formData.status === 'completed' && (
          <>
            <div className="border-t border-border/50 pt-4">
              <p className="text-xs font-bold text-muted-foreground uppercase mb-3">Match Record</p>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-green-400 uppercase mb-1 block">Wins</label>
                  <Input
                    type="number" min="0"
                    value={formData.wins ?? ''}
                    onChange={e => setFormData({...formData, wins: e.target.value ? parseInt(e.target.value) : null})}
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-red-400 uppercase mb-1 block">Losses</label>
                  <Input
                    type="number" min="0"
                    value={formData.losses ?? ''}
                    onChange={e => setFormData({...formData, losses: e.target.value ? parseInt(e.target.value) : null})}
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-primary uppercase mb-1 block">Total Matches</label>
                  <Input
                    type="number" min="0"
                    value={formData.totalMatches ?? ''}
                    onChange={e => setFormData({...formData, totalMatches: e.target.value ? parseInt(e.target.value) : null})}
                    placeholder="0"
                  />
                </div>
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase mb-2 block">Placement / Medal</label>
              <div className="flex flex-wrap gap-2">
                {[
                  { value: "1st", label: "🥇 1st", color: "border-yellow-400/50 text-yellow-400 bg-yellow-400/10" },
                  { value: "2nd", label: "🥈 2nd", color: "border-slate-400/50 text-slate-300 bg-slate-400/10" },
                  { value: "3rd", label: "🥉 3rd", color: "border-amber-600/50 text-amber-500 bg-amber-600/10" },
                  { value: "4th-6th", label: "🏅 4th–6th", color: "border-border/50 text-muted-foreground bg-secondary/30" },
                  { value: "7th+", label: "🏅 7th+", color: "border-border/50 text-muted-foreground bg-secondary/30" },
                ].map(opt => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setFormData({...formData, placement: formData.placement === opt.value ? null : opt.value})}
                    className={`px-3 py-1.5 rounded-xl text-sm font-bold border transition-all ${
                      formData.placement === opt.value ? `${opt.color} ring-2 ring-offset-1 ring-offset-background ring-current` : `border-border/30 text-muted-foreground hover:${opt.color}`
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Result Notes</label>
              <Input value={formData.result} onChange={e => setFormData({...formData, result: e.target.value})} placeholder="e.g. Won by tech fall, lost by points in final..." />
            </div>
          </>
        )}

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Notes</label>
          <Textarea value={formData.notes} onChange={(e: any) => setFormData({...formData, notes: e.target.value})} placeholder="Any additional notes..." />
        </div>

        <Button type="submit" className="w-full mt-2" disabled={isPending}>
          {isPending ? "Saving..." : existing ? "Save Changes" : "Add Event"}
        </Button>
      </form>
    </Dialog>
  );
}
