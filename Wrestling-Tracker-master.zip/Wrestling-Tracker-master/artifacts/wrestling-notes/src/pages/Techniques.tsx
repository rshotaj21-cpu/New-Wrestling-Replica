import { useState } from "react";
import { useGetTechniques, useCreateTechnique, useDeleteTechnique, useUpdateTechnique, Technique } from "@workspace/api-client-react";
import { BookOpen, Plus, Trash2, Medal, Edit2, TrendingUp, TrendingDown, Award } from "lucide-react";
import { Dialog, Input, Textarea, Select, Button } from "@/components/ui/DialogComponents";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";

const CATEGORIES = [
  { value: "neutral",       label: "Neutral",       color: "text-orange-400",  bg: "bg-orange-400/10",  border: "border-orange-400/20" },
  { value: "top",           label: "Top",            color: "text-blue-400",    bg: "bg-blue-400/10",    border: "border-blue-400/20" },
  { value: "bottom",        label: "Bottom",         color: "text-purple-400",  bg: "bg-purple-400/10",  border: "border-purple-400/20" },
  { value: "tie_up",        label: "Tie Up",         color: "text-yellow-400",  bg: "bg-yellow-400/10",  border: "border-yellow-400/20" },
  { value: "takedown",      label: "Takedown",       color: "text-orange-400",  bg: "bg-orange-400/10",  border: "border-orange-400/20" },
  { value: "scramble",      label: "Scramble",       color: "text-green-400",   bg: "bg-green-400/10",   border: "border-green-400/20" },
  { value: "top_control",   label: "Top Control",    color: "text-blue-400",    bg: "bg-blue-400/10",    border: "border-blue-400/20" },
  { value: "bottom_defense",label: "Bottom Defense", color: "text-purple-400",  bg: "bg-purple-400/10",  border: "border-purple-400/20" },
  { value: "leg_attack",    label: "Leg Attack",     color: "text-red-400",     bg: "bg-red-400/10",     border: "border-red-400/20" },
  { value: "counter",       label: "Counter",        color: "text-teal-400",    bg: "bg-teal-400/10",    border: "border-teal-400/20" },
];

const getCatMeta = (cat: string) => CATEGORIES.find(c => c.value === cat) || CATEGORIES[0];

export default function Techniques() {
  const { data: techniques, isLoading } = useGetTechniques();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editTech, setEditTech] = useState<Technique | null>(null);
  const [filter, setFilter] = useState<string>("all");
  const [view, setView] = useState<"library" | "leaderboard">("library");

  const filtered = techniques?.filter(t => filter === "all" || t.category === filter) || [];

  // Leaderboard: sort by success rate, only those with data
  const ranked = [...(techniques || [])]
    .filter(t => t.successRate !== null && t.successRate !== undefined)
    .sort((a, b) => (b.successRate || 0) - (a.successRate || 0));

  const topMove = ranked[0];
  const bottomMove = ranked[ranked.length - 1];
  const mostAttempted = [...(techniques || [])].sort((a, b) => (b.repsInSparring || 0) - (a.repsInSparring || 0))[0];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-black uppercase italic flex items-center gap-2">
            <BookOpen className="w-8 h-8 text-primary" /> Arsenal
          </h1>
          <p className="text-muted-foreground text-sm">Techniques, stats and success rates.</p>
        </div>
        <Button onClick={() => setIsAddOpen(true)} className="w-full sm:w-auto">
          <Plus className="w-5 h-5 mr-2" /> Add Technique
        </Button>
      </div>

      {/* Highlights */}
      {techniques && techniques.length > 1 && (
        <div className="grid grid-cols-3 gap-3">
          {topMove && (
            <div className="bg-green-400/10 border border-green-400/20 rounded-2xl p-3">
              <div className="flex items-center gap-1 mb-1">
                <TrendingUp className="w-3.5 h-3.5 text-green-400" />
                <span className="text-[10px] font-bold uppercase text-green-400">Best Move</span>
              </div>
              <div className="font-bold text-sm truncate">{topMove.name}</div>
              <div className="text-green-400 font-black text-lg">{topMove.successRate}%</div>
            </div>
          )}
          {mostAttempted && (
            <div className="bg-primary/10 border border-primary/20 rounded-2xl p-3">
              <div className="flex items-center gap-1 mb-1">
                <Award className="w-3.5 h-3.5 text-primary" />
                <span className="text-[10px] font-bold uppercase text-primary">Most Used</span>
              </div>
              <div className="font-bold text-sm truncate">{mostAttempted.name}</div>
              <div className="text-primary font-black text-lg">{mostAttempted.repsInSparring} reps</div>
            </div>
          )}
          {bottomMove && bottomMove.id !== topMove?.id && (
            <div className="bg-orange-400/10 border border-orange-400/20 rounded-2xl p-3">
              <div className="flex items-center gap-1 mb-1">
                <TrendingDown className="w-3.5 h-3.5 text-orange-400" />
                <span className="text-[10px] font-bold uppercase text-orange-400">Needs Work</span>
              </div>
              <div className="font-bold text-sm truncate">{bottomMove.name}</div>
              <div className="text-orange-400 font-black text-lg">{bottomMove.successRate}%</div>
            </div>
          )}
        </div>
      )}

      {/* View toggle */}
      <div className="flex rounded-xl border border-border/50 overflow-hidden w-fit">
        <button
          onClick={() => setView("library")}
          className={`px-4 py-2 text-sm font-bold transition-colors ${view === "library" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-white/5"}`}
        >
          Library
        </button>
        <button
          onClick={() => setView("leaderboard")}
          className={`px-4 py-2 text-sm font-bold transition-colors flex items-center gap-1.5 ${view === "leaderboard" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-white/5"}`}
        >
          <Medal className="w-3.5 h-3.5" /> Shot Leaderboard
        </button>
      </div>

      {view === "leaderboard" ? (
        <div className="space-y-3">
          {ranked.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground bg-card/50 rounded-2xl border border-dashed border-border/50">
              <Medal className="w-10 h-10 mx-auto mb-3 opacity-20" />
              <p>Add techniques with success rates to see your leaderboard.</p>
            </div>
          ) : (
            ranked.map((tech, i) => {
              const meta = getCatMeta(tech.category);
              const medals = ["🥇", "🥈", "🥉"];
              return (
                <motion.div
                  key={tech.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="bg-card border border-border/50 rounded-2xl p-4 flex items-center gap-4 hover:border-primary/30 transition-colors"
                >
                  <div className="text-2xl font-display font-black w-10 text-center shrink-0">
                    {i < 3 ? medals[i] : <span className="text-lg text-muted-foreground">#{i+1}</span>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded border ${meta.color} ${meta.bg} ${meta.border}`}>
                        {meta.label}
                      </span>
                      <h3 className="font-bold truncate">{tech.name}</h3>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-2 bg-secondary/50 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${i === 0 ? "bg-green-400" : i === 1 ? "bg-blue-400" : i === 2 ? "bg-yellow-400" : "bg-primary"}`}
                          style={{ width: `${tech.successRate}%` }}
                        />
                      </div>
                      <span className="text-sm font-black text-foreground shrink-0">{tech.successRate}%</span>
                    </div>
                    {tech.repsInSparring !== null && (
                      <p className="text-xs text-muted-foreground mt-0.5">{tech.repsInSparring} live attempts</p>
                    )}
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      ) : (
        <>
          {/* Category filter */}
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            <button onClick={() => setFilter("all")} className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-bold transition-colors ${filter === "all" ? "bg-foreground text-background" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>All</button>
            {["neutral", "top", "bottom", "tie_up", "takedown", "scramble", "top_control", "bottom_defense", "leg_attack", "counter"].map(cat => {
              const m = getCatMeta(cat);
              return (
                <button key={cat} onClick={() => setFilter(cat)} className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-bold transition-colors ${filter === cat ? `${m.bg.replace("/10","")}/80 ${m.color}` : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                  {m.label}
                </button>
              );
            })}
          </div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 gap-4">
              {[1,2,3,4].map(i => <div key={i} className="h-40 bg-card rounded-2xl animate-pulse" />)}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              <AnimatePresence>
                {filtered.map(tech => (
                  <TechniqueCard key={tech.id} technique={tech} onEdit={() => setEditTech(tech)} />
                ))}
              </AnimatePresence>
              {filtered.length === 0 && (
                <div className="col-span-2 text-center py-12 text-muted-foreground bg-card/50 rounded-3xl border border-dashed border-border/50">
                  <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>No techniques in this category yet.</p>
                </div>
              )}
            </div>
          )}
        </>
      )}

      <TechniqueDialog open={isAddOpen} onOpenChange={setIsAddOpen} />
      {editTech && <TechniqueDialog open={!!editTech} onOpenChange={() => setEditTech(null)} existing={editTech} />}
    </div>
  );
}

function TechniqueCard({ technique, onEdit }: { technique: Technique; onEdit: () => void }) {
  const deleteMutation = useDeleteTechnique();
  const queryClient = useQueryClient();
  const meta = getCatMeta(technique.category);

  const handleDelete = () => {
    if (confirm("Delete this technique?")) {
      deleteMutation.mutate({ id: technique.id }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/techniques"] })
      });
    }
  };

  const successRate = technique.successRate;
  const attempts = technique.repsInSparring || 0;
  const finishes = successRate !== null && successRate !== undefined ? Math.round(attempts * (successRate / 100)) : null;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={`bg-card border-l-4 border border-border/50 rounded-2xl p-5 group hover:border-primary/30 transition-all`}
      style={{ borderLeftColor: meta.color.includes("orange") ? "#fb923c" : meta.color.includes("blue") ? "#60a5fa" : meta.color.includes("purple") ? "#c084fc" : meta.color.includes("yellow") ? "#facc15" : meta.color.includes("green") ? "#4ade80" : meta.color.includes("red") ? "#f87171" : meta.color.includes("teal") ? "#2dd4bf" : "#fb923c" }}
    >
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1 min-w-0 pr-2">
          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border mb-2 inline-block ${meta.color} ${meta.bg} ${meta.border}`}>
            {meta.label}
          </span>
          <h3 className="text-xl font-bold leading-tight">{technique.name}</h3>
        </div>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={onEdit} className="p-2 text-muted-foreground hover:text-foreground hover:bg-white/5 rounded-lg">
            <Edit2 className="w-4 h-4" />
          </button>
          <button onClick={handleDelete} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Attempts / Finishes */}
      {attempts > 0 && (
        <div className="grid grid-cols-3 gap-3 mb-4 pb-4 border-b border-border/30 text-center">
          <div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mb-0.5">Attempts</div>
            <div className="text-xl font-display font-black">{attempts}</div>
          </div>
          <div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mb-0.5">Finishes</div>
            <div className="text-xl font-display font-black">{finishes ?? "—"}</div>
          </div>
          <div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mb-0.5">Rate</div>
            <div className={`text-xl font-display font-black ${successRate !== null ? (successRate >= 60 ? "text-green-400" : successRate >= 35 ? "text-yellow-400" : "text-orange-400") : "text-muted-foreground"}`}>
              {successRate !== null ? `${successRate}%` : "—"}
            </div>
          </div>
        </div>
      )}

      {successRate !== null && (
        <div className="mb-3">
          <div className="flex justify-between text-xs mb-1">
            <span className="font-bold text-muted-foreground uppercase">Success Rate</span>
            <span className={`font-bold ${successRate >= 60 ? "text-green-400" : successRate >= 35 ? "text-yellow-400" : "text-orange-400"}`}>{successRate}%</span>
          </div>
          <div className="h-3 bg-secondary/50 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${successRate}%` }}
              transition={{ duration: 0.7 }}
              className={`h-full rounded-full ${successRate >= 60 ? "bg-green-400" : successRate >= 35 ? "bg-yellow-400" : "bg-orange-400"}`}
            />
          </div>
        </div>
      )}

      {technique.notes && (
        <p className="text-sm text-muted-foreground bg-secondary/40 rounded-xl px-3 py-2 border border-border/30 mt-2">{technique.notes}</p>
      )}
    </motion.div>
  );
}

function TechniqueDialog({ open, onOpenChange, existing }: { open: boolean; onOpenChange: (o: boolean) => void; existing?: Technique }) {
  const [formData, setFormData] = useState({
    name: existing?.name || "",
    category: (existing?.category || "neutral") as any,
    date: existing?.date || new Date().toISOString().split('T')[0],
    repsInSparring: existing?.repsInSparring ?? 0,
    successRate: existing?.successRate ?? 0,
    notes: existing?.notes || "",
  });

  const createMutation = useCreateTechnique();
  const updateMutation = useUpdateTechnique();
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/techniques"] });
    onOpenChange(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (existing) {
      updateMutation.mutate({ id: existing.id, data: formData }, { onSuccess: invalidate });
    } else {
      createMutation.mutate({ data: formData }, { onSuccess: invalidate });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <div className="mb-4">
        <h2 className="text-2xl font-display font-bold">{existing ? "Edit Technique" : "Add Technique"}</h2>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Technique Name</label>
          <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. Blast Double, High Crotch, Granby Roll..." />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Category</label>
            <Select
              value={formData.category}
              onChange={v => setFormData({...formData, category: v as any})}
              options={[
                {label: 'Neutral', value: 'neutral'},
                {label: 'Top', value: 'top'},
                {label: 'Bottom', value: 'bottom'},
                {label: 'Tie Up', value: 'tie_up'},
                {label: 'Takedown', value: 'takedown'},
                {label: 'Scramble', value: 'scramble'},
                {label: 'Top Control', value: 'top_control'},
                {label: 'Bottom Defense', value: 'bottom_defense'},
                {label: 'Leg Attack', value: 'leg_attack'},
                {label: 'Counter', value: 'counter'},
              ]}
            />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Date Learned</label>
            <Input type="date" required value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Live Attempts</label>
            <Input type="number" min="0" value={formData.repsInSparring ?? 0} onChange={e => setFormData({...formData, repsInSparring: parseInt(e.target.value) || 0})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Success Rate (%)</label>
            <Input type="number" max="100" min="0" value={formData.successRate ?? 0} onChange={e => setFormData({...formData, successRate: parseInt(e.target.value) || 0})} />
          </div>
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Key Cues / Notes</label>
          <Textarea value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} placeholder="Drive through, keep head up, finish to the hip..." />
        </div>
        <Button type="submit" className="w-full" disabled={isPending}>
          {isPending ? "Saving..." : existing ? "Save Changes" : "Add to Arsenal"}
        </Button>
      </form>
    </Dialog>
  );
}
