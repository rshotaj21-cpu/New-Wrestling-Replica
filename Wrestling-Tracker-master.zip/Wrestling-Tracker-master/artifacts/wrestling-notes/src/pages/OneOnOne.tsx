import { useState } from "react";
import { useGetOneOnOneSessions, useCreateOneOnOneSession, useUpdateOneOnOneSession, useDeleteOneOnOneSession, OneOnOneSession } from "@workspace/api-client-react";
import { Users, Plus, Trash2, Edit2, Clock, BookOpen } from "lucide-react";
import { Dialog, Input, Textarea, Button } from "@/components/ui/DialogComponents";
import { formatDate } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";

export default function OneOnOne() {
  const { data: sessions, isLoading } = useGetOneOnOneSessions();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editSession, setEditSession] = useState<OneOnOneSession | null>(null);

  const totalMinutes = sessions?.reduce((sum, s) => sum + s.durationMinutes, 0) || 0;
  const totalHours = Math.round((totalMinutes / 60) * 10) / 10;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-black uppercase italic flex items-center gap-3">
            <Users className="w-8 h-8 text-purple-400" /> 1-2-1 Sessions
          </h1>
          <p className="text-muted-foreground text-sm">Private coaching sessions with your coach.</p>
        </div>
        <Button onClick={() => setIsAddOpen(true)} className="w-full sm:w-auto bg-purple-500 hover:bg-purple-600 text-white">
          <Plus className="w-5 h-5 mr-2" /> Log Session
        </Button>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-purple-400/10 border border-purple-400/20 rounded-2xl p-4 text-center">
          <div className="text-3xl font-display font-black text-purple-400">{sessions?.length || 0}</div>
          <div className="text-xs font-bold uppercase text-purple-400/80 mt-1">Total 1-2-1 Sessions</div>
        </div>
        <div className="bg-purple-400/10 border border-purple-400/20 rounded-2xl p-4 text-center">
          <div className="text-3xl font-display font-black text-purple-400">{totalHours}h</div>
          <div className="text-xs font-bold uppercase text-purple-400/80 mt-1">Total Coaching Time</div>
        </div>
      </div>

      {/* Session List */}
      {isLoading ? (
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map(i => <div key={i} className="h-32 bg-card rounded-2xl" />)}
        </div>
      ) : (
        <div className="space-y-4">
          <AnimatePresence>
            {sessions?.map(session => (
              <OOOCard
                key={session.id}
                session={session}
                onEdit={() => setEditSession(session)}
              />
            ))}
          </AnimatePresence>

          {sessions?.length === 0 && (
            <div className="text-center py-16 text-muted-foreground bg-card/50 rounded-3xl border border-dashed border-border/50">
              <Users className="w-14 h-14 mx-auto mb-4 opacity-20" />
              <p className="text-lg font-bold">No 1-2-1 sessions logged yet.</p>
              <p className="text-sm mt-1">Start tracking your private coaching sessions.</p>
              <Button className="mt-4 bg-purple-500 hover:bg-purple-600 text-white" onClick={() => setIsAddOpen(true)}>
                Log First Session
              </Button>
            </div>
          )}
        </div>
      )}

      <OOODialog open={isAddOpen} onOpenChange={setIsAddOpen} />
      {editSession && <OOODialog open={!!editSession} onOpenChange={() => setEditSession(null)} existing={editSession} />}
    </div>
  );
}

function OOOCard({ session, onEdit }: { session: OneOnOneSession; onEdit: () => void }) {
  const deleteMutation = useDeleteOneOnOneSession();
  const queryClient = useQueryClient();

  const handleDelete = () => {
    if (confirm("Delete this session?")) {
      deleteMutation.mutate({ id: session.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/one-on-one"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        }
      });
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border/50 rounded-2xl p-5 group hover:border-purple-400/40 transition-all"
    >
      <div className="flex justify-between items-start mb-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-purple-400 uppercase">{formatDate(session.date)}</span>
            <span className="w-1 h-1 rounded-full bg-muted-foreground" />
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" /> {session.durationMinutes} min
            </span>
          </div>
          <h3 className="text-xl font-bold">Session with {session.coachName}</h3>
        </div>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={onEdit} className="p-2 text-muted-foreground hover:text-foreground hover:bg-white/5 rounded-lg">
            <Edit2 className="w-4 h-4" />
          </button>
          <button onClick={handleDelete} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {session.whatLearned && (
        <div className="mb-3 p-3 bg-purple-400/10 border border-purple-400/20 rounded-xl">
          <div className="text-[10px] font-bold uppercase text-purple-400 mb-1 flex items-center gap-1">
            <BookOpen className="w-3 h-3" /> What I Learned
          </div>
          <p className="text-sm text-foreground">{session.whatLearned}</p>
        </div>
      )}

      {session.keyTechniques && (
        <div className="p-3 bg-secondary/30 rounded-xl">
          <div className="text-[10px] font-bold uppercase text-muted-foreground mb-1">Key Techniques Covered</div>
          <p className="text-sm text-muted-foreground">{session.keyTechniques}</p>
        </div>
      )}
    </motion.div>
  );
}

function OOODialog({ open, onOpenChange, existing }: { open: boolean; onOpenChange: (o: boolean) => void; existing?: OneOnOneSession }) {
  const [formData, setFormData] = useState({
    date: existing?.date || new Date().toISOString().split('T')[0],
    coachName: existing?.coachName || "",
    durationMinutes: existing?.durationMinutes || 60,
    whatLearned: existing?.whatLearned || "",
    keyTechniques: existing?.keyTechniques || "",
    notes: existing?.notes || "",
  });

  const createMutation = useCreateOneOnOneSession();
  const updateMutation = useUpdateOneOnOneSession();
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/one-on-one"] });
    queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    onOpenChange(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (existing) {
      updateMutation.mutate({ id: existing.id, data: formData }, { onSuccess: invalidate });
    } else {
      createMutation.mutate({ data: formData }, { onSuccess: invalidate });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <div className="mb-4">
        <h2 className="text-2xl font-display font-bold">{existing ? "Edit Session" : "Log 1-2-1 Session"}</h2>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Date</label>
            <Input type="date" required value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Duration (min)</label>
            <Input type="number" required value={formData.durationMinutes} onChange={e => setFormData({...formData, durationMinutes: parseInt(e.target.value)})} />
          </div>
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Coach Name</label>
          <Input required value={formData.coachName} onChange={e => setFormData({...formData, coachName: e.target.value})} placeholder="e.g. Coach Mike" />
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">What Did You Learn?</label>
          <Textarea
            value={formData.whatLearned}
            onChange={(e: any) => setFormData({...formData, whatLearned: e.target.value})}
            placeholder="Main takeaways from this session..."
          />
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Key Techniques Covered</label>
          <Textarea
            value={formData.keyTechniques}
            onChange={(e: any) => setFormData({...formData, keyTechniques: e.target.value})}
            placeholder="Techniques, entries, finishing details covered..."
          />
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Additional Notes</label>
          <Textarea value={formData.notes} onChange={(e: any) => setFormData({...formData, notes: e.target.value})} placeholder="Any other notes..." />
        </div>
        <Button type="submit" className="w-full bg-purple-500 hover:bg-purple-600 text-white" disabled={isPending}>
          {isPending ? "Saving..." : existing ? "Save Changes" : "Log Session"}
        </Button>
      </form>
    </Dialog>
  );
}
