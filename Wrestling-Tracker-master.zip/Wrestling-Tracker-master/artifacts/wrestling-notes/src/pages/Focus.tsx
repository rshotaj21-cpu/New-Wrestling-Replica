import { useState } from "react";
import { useEffect } from "react";
import { useGetFocusSessions, useCreateFocusSession, useDeleteFocusSession, useUpdateFocusSession, FocusSession } from "@workspace/api-client-react";
import { Target, Play, Square, Plus, Trash2, CheckCircle2, Edit2, BookOpen, Zap } from "lucide-react";
import { Dialog, Input, Textarea, Select, Button } from "@/components/ui/DialogComponents";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";

const REP_PRESETS = [10, 25, 50, 100];
const PERIOD_OPTIONS = [
  { label: "1 Week", value: 7 },
  { label: "2 Weeks", value: 14 },
  { label: "1 Month", value: 30 },
  { label: "6 Weeks", value: 42 },
  { label: "3 Months", value: 90 },
];

export default function Focus() {
  const { data: sessions, isLoading } = useGetFocusSessions();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editSession, setEditSession] = useState<FocusSession | null>(null);
  const [activeTimerId, setActiveTimerId] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const queryClient = useQueryClient();
  const updateMutation = useUpdateFocusSession();
  const deleteMutation = useDeleteFocusSession();

  useEffect(() => {
    let interval: any = null;
    if (activeTimerId !== null && timeLeft > 0) {
      interval = setInterval(() => setTimeLeft(t => t - 1), 1000);
    } else if (timeLeft === 0 && activeTimerId !== null) {
      const session = sessions?.find(s => s.id === activeTimerId);
      if (session) {
        updateMutation.mutate({ id: session.id, data: { ...session, progress: 'completed' as any } }, {
          onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/focus"] })
        });
      }
      setActiveTimerId(null);
    }
    return () => clearInterval(interval);
  }, [activeTimerId, timeLeft]);

  const toggleTimer = (session: FocusSession) => {
    if (activeTimerId === session.id) {
      setActiveTimerId(null);
    } else {
      setActiveTimerId(session.id);
      setTimeLeft(session.durationMinutes * 60);
      if (session.progress === 'planned') {
        updateMutation.mutate({ id: session.id, data: { ...session, progress: 'in_progress' as any } }, {
          onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/focus"] })
        });
      }
    }
  };

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  const handleDelete = (id: number) => {
    if (confirm("Delete this focus session?")) {
      deleteMutation.mutate({ id }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/focus"] }) });
    }
  };

  const active = sessions?.filter(s => s.progress !== 'completed') || [];
  const completed = sessions?.filter(s => s.progress === 'completed') || [];

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-card border border-border/50 p-6 md:p-10">
        <div className="absolute inset-0 z-0">
          <img src={`${import.meta.env.BASE_URL}images/focus-bg.png`} alt="" className="w-full h-full object-cover opacity-25 mix-blend-color-dodge" />
          <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <h1 className="text-4xl md:text-5xl font-display font-black uppercase italic text-white flex items-center gap-3">
              <Target className="w-10 h-10 text-accent" /> Hyper Focus
            </h1>
            <p className="text-muted-foreground mt-2">Isolate movements. Grind reps. Build muscle memory.</p>
          </div>
          <Button onClick={() => setIsAddOpen(true)} className="w-full md:w-auto bg-accent text-accent-foreground hover:bg-accent/90">
            <Plus className="w-5 h-5 mr-2" /> New Focus Target
          </Button>
        </div>
      </div>

      {/* Active Timer Display */}
      {activeTimerId !== null && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-primary text-primary-foreground rounded-3xl p-8 text-center shadow-2xl shadow-primary/30 border border-white/20"
        >
          <h2 className="text-sm font-bold uppercase tracking-widest opacity-80 mb-2">
            {sessions?.find(s => s.id === activeTimerId)?.techniqueName} — Active Drill
          </h2>
          <div className="text-8xl md:text-9xl font-display font-black tracking-tighter tabular-nums">
            {formatTime(timeLeft)}
          </div>
          <div className="mt-2 text-sm opacity-70">
            {Math.round((1 - timeLeft / ((sessions?.find(s => s.id === activeTimerId)?.durationMinutes || 1) * 60)) * 100)}% complete
          </div>
          <Button variant="outline" className="mt-6 border-white/30 hover:bg-white/20 text-white" onClick={() => setActiveTimerId(null)}>
            <Square className="w-4 h-4 mr-2 fill-current" /> Stop Drill
          </Button>
        </motion.div>
      )}

      {/* Active Focus Targets */}
      {active.length > 0 && (
        <div>
          <h2 className="text-lg font-bold mb-3 flex items-center gap-2"><Zap className="w-5 h-5 text-accent" /> Active Targets</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <AnimatePresence>
              {active.map(session => (
                <FocusCard
                  key={session.id}
                  session={session}
                  isTimerActive={activeTimerId === session.id}
                  onToggleTimer={() => toggleTimer(session)}
                  onEdit={() => setEditSession(session)}
                  onDelete={() => handleDelete(session.id)}
                  onComplete={() => {
                    updateMutation.mutate({ id: session.id, data: { ...session, progress: 'completed' as any, completedReps: session.targetReps } }, {
                      onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/focus"] })
                    });
                  }}
                />
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* Completed */}
      {completed.length > 0 && (
        <div>
          <h2 className="text-lg font-bold mb-3 flex items-center gap-2 text-muted-foreground"><CheckCircle2 className="w-5 h-5 text-accent" /> Completed</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {completed.map(session => (
              <FocusCard
                key={session.id}
                session={session}
                isTimerActive={false}
                onToggleTimer={() => {}}
                onEdit={() => setEditSession(session)}
                onDelete={() => handleDelete(session.id)}
                onComplete={() => {}}
              />
            ))}
          </div>
        </div>
      )}

      {!isLoading && sessions?.length === 0 && (
        <div className="text-center py-16 text-muted-foreground bg-card/50 rounded-3xl border border-dashed border-border/50">
          <Target className="w-14 h-14 mx-auto mb-4 opacity-20" />
          <p className="text-lg font-bold">No focus targets yet.</p>
          <p className="text-sm mt-1">Pick a technique to master and set your goal.</p>
          <Button className="mt-4 bg-accent text-accent-foreground" onClick={() => setIsAddOpen(true)}>Set First Target</Button>
        </div>
      )}

      <FocusDialog open={isAddOpen} onOpenChange={setIsAddOpen} />
      {editSession && <FocusDialog open={!!editSession} onOpenChange={() => setEditSession(null)} existing={editSession} />}
    </div>
  );
}

function FocusCard({ session, isTimerActive, onToggleTimer, onEdit, onDelete, onComplete }: {
  session: FocusSession;
  isTimerActive: boolean;
  onToggleTimer: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onComplete: () => void;
}) {
  const repProgress = session.repGoal ? Math.min(100, Math.round((session.completedReps / session.repGoal) * 100)) : null;
  const isCompleted = session.progress === 'completed';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`bg-card border rounded-2xl p-5 relative overflow-hidden group transition-all ${
        isTimerActive ? 'border-primary shadow-lg shadow-primary/10' :
        isCompleted ? 'border-accent/30 bg-accent/5' : 'border-border/50 hover:border-border'
      }`}
    >
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1 min-w-0 pr-2">
          <h3 className="text-lg font-bold truncate">{session.techniqueName}</h3>
          {session.focusPeriodDays && (
            <span className="text-xs text-muted-foreground">{session.focusPeriodDays}-day focus</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
            isCompleted ? 'bg-accent/20 text-accent' :
            session.progress === 'in_progress' ? 'bg-primary/20 text-primary' : 'bg-secondary text-muted-foreground'
          }`}>
            {session.progress.replace('_', ' ')}
          </span>
        </div>
      </div>

      {/* Rep Goal Progress */}
      {session.repGoal && (
        <div className="mb-4">
          <div className="flex justify-between text-xs mb-1">
            <span className="font-bold text-muted-foreground">Mastery Progress</span>
            <span className="font-bold text-foreground">{session.completedReps}/{session.repGoal} reps</span>
          </div>
          <div className="w-full h-2 bg-secondary/50 rounded-full overflow-hidden">
            <div className="h-full bg-accent rounded-full transition-all" style={{ width: `${repProgress}%` }} />
          </div>
          <p className="text-xs text-accent font-bold mt-1">{repProgress}% to mastery</p>
        </div>
      )}

      <div className="grid grid-cols-3 gap-3 mb-4 pb-4 border-b border-border/30 text-center">
        <div>
          <div className="text-[10px] font-bold uppercase text-muted-foreground mb-0.5">Session Reps</div>
          <div className="text-lg font-display font-bold">{session.targetReps}</div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase text-muted-foreground mb-0.5">Done</div>
          <div className="text-lg font-display font-bold">{session.completedReps}</div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase text-muted-foreground mb-0.5">Duration</div>
          <div className="text-lg font-display font-bold">{session.durationMinutes}m</div>
        </div>
      </div>

      {/* Drill method / game plan preview */}
      {(session.drillMethod || session.gamePlanNotes) && (
        <div className="mb-4 space-y-2">
          {session.drillMethod && (
            <div className="text-xs text-muted-foreground bg-secondary/30 rounded-lg px-3 py-2 line-clamp-2">
              <span className="font-bold text-foreground/60">Drill: </span>{session.drillMethod}
            </div>
          )}
          {session.gamePlanNotes && (
            <div className="text-xs text-muted-foreground bg-accent/10 rounded-lg px-3 py-2 line-clamp-2">
              <span className="font-bold text-accent/80">Game Plan: </span>{session.gamePlanNotes}
            </div>
          )}
        </div>
      )}

      {!isCompleted && (
        <div className="flex gap-2">
          <Button onClick={onToggleTimer} className="flex-1 bg-secondary text-foreground hover:bg-white/10">
            {isTimerActive ? <><Square className="w-4 h-4 mr-2" /> Stop</> : <><Play className="w-4 h-4 mr-2" /> Start Timer</>}
          </Button>
          <Button variant="outline" className="flex-1 border-accent/20 text-accent hover:bg-accent/10" onClick={onComplete}>
            <CheckCircle2 className="w-4 h-4 mr-2" /> Complete
          </Button>
        </div>
      )}

      <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <button onClick={onEdit} className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-white/5 rounded-lg">
          <Edit2 className="w-3.5 h-3.5" />
        </button>
        <button onClick={onDelete} className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </motion.div>
  );
}

function FocusDialog({ open, onOpenChange, existing }: { open: boolean; onOpenChange: (o: boolean) => void; existing?: FocusSession }) {
  const [customReps, setCustomReps] = useState(false);
  const [formData, setFormData] = useState({
    techniqueName: existing?.techniqueName || "",
    targetReps: existing?.targetReps || 20,
    completedReps: existing?.completedReps || 0,
    repGoal: existing?.repGoal || null as number | null,
    durationMinutes: existing?.durationMinutes || 10,
    focusPeriodDays: existing?.focusPeriodDays || null as number | null,
    drillMethod: existing?.drillMethod || "",
    gamePlanNotes: existing?.gamePlanNotes || "",
    focusReason: existing?.focusReason || "",
    progress: (existing?.progress || "planned") as any,
    notes: existing?.notes || "",
    date: existing?.date || new Date().toISOString().split('T')[0],
  });

  const createMutation = useCreateFocusSession();
  const updateMutation = useUpdateFocusSession();
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/focus"] });
    queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    onOpenChange(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { ...formData };
    if (existing) {
      updateMutation.mutate({ id: existing.id, data: payload }, { onSuccess: invalidate });
    } else {
      createMutation.mutate({ data: payload }, { onSuccess: invalidate });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <div className="mb-4">
        <h2 className="text-2xl font-display font-bold">{existing ? "Edit Focus Target" : "New Focus Target"}</h2>
        <p className="text-sm text-muted-foreground mt-1">Pick a technique and set your mastery plan.</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Technique / Movement</label>
          <Input required value={formData.techniqueName} onChange={e => setFormData({...formData, techniqueName: e.target.value})} placeholder="e.g. High Crotch to Finish, Ankle Pick Entry..." />
        </div>

        {/* Focus Period */}
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-2 block">Focus Period</label>
          <div className="flex flex-wrap gap-2">
            {PERIOD_OPTIONS.map(p => (
              <button
                key={p.value}
                type="button"
                onClick={() => setFormData({...formData, focusPeriodDays: formData.focusPeriodDays === p.value ? null : p.value})}
                className={`px-3 py-1.5 rounded-lg text-sm font-bold border transition-all ${
                  formData.focusPeriodDays === p.value
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'bg-secondary border-border/50 text-muted-foreground hover:border-primary/40'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Rep Goal (Mastery Target) */}
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-2 block">Mastery Rep Goal</label>
          <p className="text-xs text-muted-foreground mb-2">Total successful reps to master this technique</p>
          <div className="flex flex-wrap gap-2 mb-2">
            {REP_PRESETS.map(r => (
              <button
                key={r}
                type="button"
                onClick={() => { setCustomReps(false); setFormData({...formData, repGoal: formData.repGoal === r ? null : r}); }}
                className={`px-3 py-1.5 rounded-lg text-sm font-bold border transition-all ${
                  !customReps && formData.repGoal === r
                    ? 'bg-accent text-accent-foreground border-accent'
                    : 'bg-secondary border-border/50 text-muted-foreground hover:border-accent/40'
                }`}
              >
                {r} reps
              </button>
            ))}
            <button
              type="button"
              onClick={() => setCustomReps(true)}
              className={`px-3 py-1.5 rounded-lg text-sm font-bold border transition-all ${
                customReps ? 'bg-accent text-accent-foreground border-accent' : 'bg-secondary border-border/50 text-muted-foreground hover:border-accent/40'
              }`}
            >
              Custom
            </button>
          </div>
          {customReps && (
            <Input
              type="number" min="1" placeholder="Custom rep goal..."
              value={formData.repGoal || ''}
              onChange={e => setFormData({...formData, repGoal: parseInt(e.target.value) || null})}
            />
          )}
        </div>

        {/* Session drill details */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Reps per Session</label>
            <Input type="number" required value={formData.targetReps} onChange={e => setFormData({...formData, targetReps: parseInt(e.target.value)})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Timer (min)</label>
            <Input type="number" required value={formData.durationMinutes} onChange={e => setFormData({...formData, durationMinutes: parseInt(e.target.value)})} />
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Why This Technique?</label>
          <Textarea
            value={formData.focusReason}
            onChange={(e: any) => setFormData({...formData, focusReason: e.target.value})}
            placeholder="Why are you focusing on this? What problem does it solve in your game?"
          />
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Game Plan / Strategy</label>
          <Textarea
            value={formData.gamePlanNotes}
            onChange={(e: any) => setFormData({...formData, gamePlanNotes: e.target.value})}
            placeholder="How will you drill it? What setups / combinations? What's the goal entry?"
          />
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Drill Method / Constraints</label>
          <Textarea
            value={formData.drillMethod}
            onChange={(e: any) => setFormData({...formData, drillMethod: e.target.value})}
            placeholder="e.g. Partner gives 50% resistance on finish, shadow drill first..."
          />
        </div>

        <Button type="submit" className="w-full bg-accent text-accent-foreground hover:bg-accent/90" disabled={isPending}>
          {isPending ? "Saving..." : existing ? "Save Changes" : "Set Focus Target"}
        </Button>
      </form>
    </Dialog>
  );
}
