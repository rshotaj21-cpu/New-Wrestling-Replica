import { useGetStats, useGetTechniques, useGetSessions } from "@workspace/api-client-react";
import { Activity, Clock, Trophy, Swords, Target, TrendingUp, TrendingDown, Flame, Medal, BarChart3, Users } from "lucide-react";
import { motion } from "framer-motion";

export default function Stats() {
  const { data: stats } = useGetStats();
  const { data: techniques } = useGetTechniques();
  const { data: sessions } = useGetSessions();

  // Technique leaderboard
  const rankedTechs = [...(techniques || [])]
    .filter(t => t.successRate !== null)
    .sort((a, b) => (b.successRate || 0) - (a.successRate || 0));

  const topMove = rankedTechs[0];
  const worstMove = rankedTechs[rankedTechs.length - 1];
  const mostAttempted = [...(techniques || [])].sort((a, b) => (b.repsInSparring || 0) - (a.repsInSparring || 0))[0];

  const winRate = (stats?.totalCompetitionMatches || 0) > 0
    ? Math.round(((stats?.totalWins || 0) / (stats?.totalCompetitionMatches || 1)) * 100)
    : null;

  // Monthly session breakdown for heatmap
  const monthlyData = (() => {
    if (!sessions) return [];
    const counts: Record<string, number> = {};
    for (const s of sessions) {
      const key = s.date.substring(0, 7); // yyyy-MM
      counts[key] = (counts[key] || 0) + 1;
    }
    const now = new Date();
    const result = [];
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      result.push({ key, month: d.toLocaleString('default', { month: 'short' }), count: counts[key] || 0 });
    }
    return result;
  })();

  const maxMonthly = Math.max(...monthlyData.map(m => m.count), 1);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-black uppercase italic flex items-center gap-2">
          <BarChart3 className="w-8 h-8 text-primary" /> Stats
        </h1>
        <p className="text-muted-foreground text-sm">Your long-term performance at a glance.</p>
      </div>

      {/* Streak highlight */}
      {(stats?.currentStreak || 0) > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-primary/20 via-primary/10 to-transparent border border-primary/30 rounded-2xl p-5 flex items-center gap-5"
        >
          <div className="text-5xl font-display font-black text-primary">{stats?.currentStreak}</div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Flame className="w-5 h-5 text-primary" />
              <span className="font-bold text-foreground text-lg">Week Streak 🔥</span>
            </div>
            <p className="text-muted-foreground text-sm">You've trained every week for {stats?.currentStreak} week{stats?.currentStreak !== 1 ? 's' : ''} straight. Keep it alive.</p>
          </div>
        </motion.div>
      )}

      {/* ─── TRAINING ─── */}
      <Section title="Training" icon={Activity} color="text-primary">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <BigStat label="Total Sessions" value={stats?.totalSessions || 0} color="text-primary" />
          <BigStat label="Mat Time" value={`${stats?.totalMatTimeHours || 0}h`} color="text-blue-400" />
          <BigStat label="Avg Session" value={stats?.avgSessionLengthMinutes ? `${stats.avgSessionLengthMinutes}m` : "—"} color="text-cyan-400" />
          <BigStat label="Sparring Rounds" value={stats?.totalSparringRounds || 0} color="text-green-400" />
        </div>

        {/* Monthly session heatmap */}
        <div className="bg-card border border-border/50 rounded-2xl p-5 mt-3">
          <h3 className="text-sm font-bold uppercase text-muted-foreground mb-4">Sessions per Month (Last 12 Months)</h3>
          <div className="flex items-end gap-1.5 h-20">
            {monthlyData.map((m, i) => {
              const heightPct = m.count === 0 ? 4 : Math.max(8, Math.round((m.count / maxMonthly) * 100));
              const color = m.count === 0 ? "bg-secondary/30" : m.count >= maxMonthly * 0.7 ? "bg-primary" : m.count >= maxMonthly * 0.4 ? "bg-primary/60" : "bg-primary/30";
              return (
                <div key={m.key} className="flex-1 flex flex-col items-center gap-1">
                  <div className="w-full flex flex-col justify-end" style={{ height: "64px" }}>
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${heightPct}%` }}
                      transition={{ duration: 0.5, delay: i * 0.03 }}
                      className={`w-full rounded-sm ${color}`}
                      title={`${m.month}: ${m.count} sessions`}
                    />
                  </div>
                  <span className="text-[9px] font-bold text-muted-foreground">{m.month}</span>
                  {m.count > 0 && <span className="text-[9px] font-black text-primary">{m.count}</span>}
                </div>
              );
            })}
          </div>
        </div>

        {/* Session progress toward annual target */}
        {stats?.weeklySessionsTarget && (
          <div className="bg-card border border-border/50 rounded-2xl p-4 mt-3">
            <div className="flex justify-between mb-2">
              <span className="text-sm font-bold">Annual Session Goal</span>
              <span className="text-sm font-bold text-primary">{stats?.sessionsThisYear || 0} / {(stats?.weeklySessionsTarget || 3) * 52}</span>
            </div>
            <div className="h-3 bg-secondary/50 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, Math.round(((stats?.sessionsThisYear || 0) / ((stats?.weeklySessionsTarget || 3) * 52)) * 100))}%` }}
                className="h-full bg-primary rounded-full"
              />
            </div>
          </div>
        )}

        {/* 1-2-1 sessions */}
        {(stats?.oneOnOneCount || 0) > 0 && (
          <div className="flex items-center gap-4 bg-purple-400/10 border border-purple-400/20 rounded-2xl p-4 mt-3">
            <Users className="w-8 h-8 text-purple-400 shrink-0" />
            <div>
              <div className="text-2xl font-display font-black text-purple-400">{stats?.oneOnOneCount}</div>
              <div className="text-xs font-bold uppercase text-purple-400/70">Private Coaching Sessions</div>
            </div>
          </div>
        )}
      </Section>

      {/* ─── COMPETITION ─── */}
      <Section title="Competition" icon={Trophy} color="text-yellow-400">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <BigStat label="Events Entered" value={stats?.totalCompetitions || 0} color="text-yellow-400" />
          <BigStat label="Matches Wrestled" value={stats?.totalCompetitionMatches || (stats?.totalWins || 0) + (stats?.totalLosses || 0)} color="text-primary" />
          <BigStat label="Total Wins" value={stats?.totalWins || 0} color="text-green-400" />
          <BigStat label="Total Losses" value={stats?.totalLosses || 0} color="text-red-400" />
        </div>

        {winRate !== null && (
          <div className="bg-card border border-border/50 rounded-2xl p-4 mt-3">
            <div className="flex justify-between mb-2">
              <span className="text-sm font-bold flex items-center gap-2"><TrendingUp className="w-4 h-4 text-green-400" /> Win Rate</span>
              <span className={`text-xl font-display font-black ${winRate >= 60 ? "text-green-400" : winRate >= 40 ? "text-yellow-400" : "text-orange-400"}`}>{winRate}%</span>
            </div>
            <div className="h-3 bg-red-400/20 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${winRate}%` }}
                className="h-full bg-green-400 rounded-full"
              />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>{stats?.totalWins || 0} W</span>
              <span>{stats?.totalLosses || 0} L</span>
            </div>
          </div>
        )}
      </Section>

      {/* ─── TECHNIQUES ─── */}
      <Section title="Technique Analytics" icon={Swords} color="text-accent">
        {techniques && techniques.length > 0 ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
              {topMove && (
                <div className="bg-green-400/10 border border-green-400/20 rounded-2xl p-4">
                  <div className="flex items-center gap-1 mb-2 text-green-400 text-xs font-bold uppercase">
                    <TrendingUp className="w-3.5 h-3.5" /> Best Success Rate
                  </div>
                  <div className="font-bold">{topMove.name}</div>
                  <div className="text-3xl font-display font-black text-green-400">{topMove.successRate}%</div>
                </div>
              )}
              {mostAttempted && (
                <div className="bg-primary/10 border border-primary/20 rounded-2xl p-4">
                  <div className="flex items-center gap-1 mb-2 text-primary text-xs font-bold uppercase">
                    <Target className="w-3.5 h-3.5" /> Most Attempted
                  </div>
                  <div className="font-bold">{mostAttempted.name}</div>
                  <div className="text-3xl font-display font-black text-primary">{mostAttempted.repsInSparring}</div>
                  <div className="text-xs text-muted-foreground">live reps</div>
                </div>
              )}
              {worstMove && worstMove.id !== topMove?.id && (
                <div className="bg-orange-400/10 border border-orange-400/20 rounded-2xl p-4">
                  <div className="flex items-center gap-1 mb-2 text-orange-400 text-xs font-bold uppercase">
                    <TrendingDown className="w-3.5 h-3.5" /> Lowest Success Rate
                  </div>
                  <div className="font-bold">{worstMove.name}</div>
                  <div className="text-3xl font-display font-black text-orange-400">{worstMove.successRate}%</div>
                </div>
              )}
            </div>

            {/* Full leaderboard */}
            {rankedTechs.length > 0 && (
              <div className="bg-card border border-border/50 rounded-2xl p-4">
                <h3 className="text-sm font-bold uppercase text-muted-foreground mb-3 flex items-center gap-2"><Medal className="w-4 h-4" /> Shot Success Leaderboard</h3>
                <div className="space-y-3">
                  {rankedTechs.map((tech, i) => (
                    <div key={tech.id} className="flex items-center gap-3">
                      <span className="text-lg w-7 text-center shrink-0">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : <span className="text-sm font-bold text-muted-foreground">#{i+1}</span>}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="font-bold truncate">{tech.name}</span>
                          <span className="font-bold text-foreground shrink-0 ml-2">{tech.successRate}%</span>
                        </div>
                        <div className="h-2 bg-secondary/50 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${(tech.successRate || 0) >= 60 ? "bg-green-400" : (tech.successRate || 0) >= 35 ? "bg-yellow-400" : "bg-orange-400"}`}
                            style={{ width: `${tech.successRate}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-8 text-muted-foreground bg-card/50 rounded-2xl border border-dashed border-border/50">
            <Swords className="w-10 h-10 mx-auto mb-3 opacity-20" />
            <p>Add techniques with success rates to see analytics here.</p>
          </div>
        )}
      </Section>
    </div>
  );
}

function Section({ title, icon: Icon, color, children }: { title: string; icon: any; color: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className={`text-xl font-display font-bold flex items-center gap-2 mb-4 ${color}`}>
        <Icon className="w-5 h-5" /> {title}
      </h2>
      {children}
    </div>
  );
}

function BigStat({ label, value, color }: { label: string; value: any; color: string }) {
  return (
    <div className="bg-card border border-border/50 rounded-2xl p-4 text-center hover:bg-white/[0.02] transition-colors">
      <div className={`text-3xl font-display font-black ${color}`}>{value}</div>
      <div className="text-xs font-bold uppercase text-muted-foreground mt-1">{label}</div>
    </div>
  );
}
