import { useState } from "react";
import { useGetSparringSessions, useCreateSparringSession, useUpdateSparringSession, useDeleteSparringSession, SparringSession } from "@workspace/api-client-react";
import { Swords, Plus, Trash2, Activity, Clock, Edit2, Zap } from "lucide-react";
import { Dialog, Input, Textarea, Select, Button } from "@/components/ui/DialogComponents";
import { formatDate } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";

function RatingBar({ label, value, max = 5, color }: { label: string; value: number; max?: number; color: string }) {
  const pct = Math.round((value / max) * 100);
  return (
    <div className="flex-1">
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs font-bold uppercase text-muted-foreground">{label}</span>
        <span className={`text-sm font-black ${color}`}>{value}/{max}</span>
      </div>
      <div className="h-3 bg-secondary/60 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className={`h-full rounded-full ${color.replace("text-", "bg-")}`}
        />
      </div>
    </div>
  );
}

export default function Sparring() {
  const { data: sessions, isLoading } = useGetSparringSessions();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editSession, setEditSession] = useState<SparringSession | null>(null);

  const totalRounds = sessions?.reduce((acc, s) => acc + s.rounds, 0) || 0;
  const totalMinutes = sessions?.reduce((acc, s) => acc + (s.rounds * s.roundDurationSeconds / 60), 0) || 0;
  const avgEndurance = sessions?.length ? Math.round((sessions.reduce((a,s) => a + s.enduranceRating, 0) / sessions.length) * 10) / 10 : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-black uppercase italic flex items-center gap-2">
            <Swords className="w-8 h-8 text-green-400" /> Sparring Log
          </h1>
          <p className="text-muted-foreground text-sm">Track your live rolls and gas tank.</p>
        </div>
        <Button onClick={() => setIsAddOpen(true)} className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white">
          <Plus className="w-5 h-5 mr-2" /> Log Sparring
        </Button>
      </div>

      {/* Summary */}
      {sessions && sessions.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-3 text-center">
            <div className="text-2xl font-display font-black text-green-400">{sessions.length}</div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mt-0.5">Sessions</div>
          </div>
          <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-3 text-center">
            <div className="text-2xl font-display font-black text-green-400">{totalRounds}</div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mt-0.5">Total Rounds</div>
          </div>
          <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-3 text-center">
            <div className="text-2xl font-display font-black text-green-400">{avgEndurance}/5</div>
            <div className="text-[10px] font-bold uppercase text-muted-foreground mt-0.5">Avg Endurance</div>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="animate-pulse space-y-4">{[1,2,3].map(i => <div key={i} className="h-40 bg-card rounded-2xl" />)}</div>
      ) : (
        <div className="grid gap-4">
          <AnimatePresence>
            {sessions?.map(session => (
              <SparringCard key={session.id} session={session} onEdit={() => setEditSession(session)} />
            ))}
            {sessions?.length === 0 && (
              <div className="text-center py-12 text-muted-foreground bg-card/50 rounded-3xl border border-dashed border-border/50">
                <Swords className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p>No sparring logged yet. Time to roll!</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      )}

      <SparringDialog open={isAddOpen} onOpenChange={setIsAddOpen} />
      {editSession && <SparringDialog open={!!editSession} onOpenChange={() => setEditSession(null)} existing={editSession} />}
    </div>
  );
}

function SparringCard({ session, onEdit }: { session: SparringSession; onEdit: () => void }) {
  const deleteMutation = useDeleteSparringSession();
  const queryClient = useQueryClient();

  const handleDelete = () => {
    if (confirm("Delete this sparring log?")) {
      deleteMutation.mutate({ id: session.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/sparring"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        }
      });
    }
  };

  const totalMinutes = Math.round(session.rounds * session.roundDurationSeconds / 60);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-card border-l-4 border-l-green-500 border border-border/50 rounded-2xl p-5 group hover:border-green-500/30 transition-all"
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-green-500/10 border border-green-500/20 text-green-400 flex flex-col items-center justify-center">
            <span className="text-2xl font-display font-black leading-none">{session.rounds}</span>
            <span className="text-[9px] font-bold uppercase opacity-70">rounds</span>
          </div>
          <div>
            <h3 className="text-lg font-bold">{formatDate(session.date)}</h3>
            <div className="flex items-center gap-3 text-sm text-muted-foreground mt-0.5">
              <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {session.roundDurationSeconds / 60} min/round</span>
              <span className="flex items-center gap-1"><Zap className="w-3.5 h-3.5" /> {totalMinutes} min total</span>
            </div>
          </div>
        </div>

        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={onEdit} className="p-2 text-muted-foreground hover:text-foreground hover:bg-white/5 rounded-lg">
            <Edit2 className="w-4 h-4" />
          </button>
          <button onClick={handleDelete} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Rating bars */}
      <div className="space-y-3 mb-4">
        <RatingBar label="Endurance" value={session.enduranceRating} color="text-green-400" />
        <RatingBar label="Performance" value={session.roundsRating} color="text-blue-400" />
      </div>

      {(session.wentWell || session.needsWork) && (
        <div className="grid sm:grid-cols-2 gap-3 pt-4 border-t border-border/30">
          {session.wentWell && (
            <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-xl p-3">
              <div className="text-xs font-bold text-emerald-400 uppercase mb-1">✓ Worked Well</div>
              <p className="text-sm text-muted-foreground">{session.wentWell}</p>
            </div>
          )}
          {session.needsWork && (
            <div className="bg-orange-500/5 border border-orange-500/10 rounded-xl p-3">
              <div className="text-xs font-bold text-orange-400 uppercase mb-1">⚠ Exposed</div>
              <p className="text-sm text-muted-foreground">{session.needsWork}</p>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}

function SparringDialog({ open, onOpenChange, existing }: { open: boolean; onOpenChange: (o: boolean) => void; existing?: SparringSession }) {
  const [formData, setFormData] = useState({
    date: existing?.date || new Date().toISOString().split('T')[0],
    rounds: existing?.rounds || 5,
    roundDurationSeconds: existing?.roundDurationSeconds || 300,
    enduranceRating: existing?.enduranceRating || 3,
    roundsRating: existing?.roundsRating || 3,
    wentWell: existing?.wentWell || "",
    needsWork: existing?.needsWork || "",
    notes: existing?.notes || "",
  });

  const createMutation = useCreateSparringSession();
  const updateMutation = useUpdateSparringSession();
  const queryClient = useQueryClient();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/sparring"] });
    queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    onOpenChange(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (existing) {
      updateMutation.mutate({ id: existing.id, data: formData }, { onSuccess: invalidate });
    } else {
      createMutation.mutate({ data: formData }, { onSuccess: invalidate });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <div className="mb-4">
        <h2 className="text-2xl font-display font-bold">{existing ? "Edit Sparring Log" : "Log Sparring"}</h2>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Date</label>
            <Input type="date" required value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Rounds</label>
            <Input type="number" required min="1" value={formData.rounds} onChange={e => setFormData({...formData, rounds: parseInt(e.target.value)})} />
          </div>
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Minutes per Round</label>
            <Input type="number" required min="1" value={formData.roundDurationSeconds / 60} onChange={e => setFormData({...formData, roundDurationSeconds: parseInt(e.target.value) * 60})} />
          </div>
        </div>

        {/* Rating sliders */}
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-xs font-bold text-muted-foreground uppercase">Endurance (1–5)</label>
              <span className="text-sm font-bold text-green-400">{formData.enduranceRating}/5</span>
            </div>
            <input type="range" min="1" max="5" value={formData.enduranceRating}
              onChange={e => setFormData({...formData, enduranceRating: parseInt(e.target.value)})}
              className="w-full accent-green-500"
            />
            <div className="flex justify-between text-[10px] text-muted-foreground mt-0.5">
              <span>Gassed</span><span>Iron lungs</span>
            </div>
          </div>
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-xs font-bold text-muted-foreground uppercase">Performance (1–5)</label>
              <span className="text-sm font-bold text-blue-400">{formData.roundsRating}/5</span>
            </div>
            <input type="range" min="1" max="5" value={formData.roundsRating}
              onChange={e => setFormData({...formData, roundsRating: parseInt(e.target.value)})}
              className="w-full accent-blue-500"
            />
            <div className="flex justify-between text-[10px] text-muted-foreground mt-0.5">
              <span>Rough</span><span>Dominant</span>
            </div>
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">What worked?</label>
          <Textarea value={formData.wentWell} onChange={e => setFormData({...formData, wentWell: e.target.value})} placeholder="Shots were sharp, defended well on bottom..." />
        </div>
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">What got exposed?</label>
          <Textarea value={formData.needsWork} onChange={e => setFormData({...formData, needsWork: e.target.value})} placeholder="Got pinned on double legs, tired in round 4..." />
        </div>

        <Button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white" disabled={isPending}>
          {isPending ? "Saving..." : existing ? "Save Changes" : "Log Sparring"}
        </Button>
      </form>
    </Dialog>
  );
}
