import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateString: string) {
  if (!dateString) return "";
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', { 
    month: 'short', 
    day: 'numeric',
    year: 'numeric'
  }).format(date);
}

export function getCategoryColor(category: string) {
  switch (category) {
    case 'takedown': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
    case 'scramble': return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
    case 'top_control': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    case 'bottom_defense': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
    case 'tie_up': return 'bg-orange-500/10 text-orange-400 border-orange-500/20';
    case 'leg_attack': return 'bg-red-500/10 text-red-400 border-red-500/20';
    case 'counter': return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
    default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
  }
}

export function getCategoryLabel(category: string) {
  return category.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}
