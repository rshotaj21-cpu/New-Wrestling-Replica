import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { strengthConditioningTable, insertStrengthConditioningSchema } from "@workspace/db/schema";
import { eq, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/strength-conditioning", async (_req, res) => {
  try {
    const sessions = await db.select().from(strengthConditioningTable)
      .orderBy(sql`${strengthConditioningTable.date} DESC`);
    res.json(sessions);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch S&C sessions" });
  }
});

router.post("/strength-conditioning", async (req, res) => {
  try {
    const data = insertStrengthConditioningSchema.parse(req.body);
    const [session] = await db.insert(strengthConditioningTable).values(data).returning();
    res.status(201).json(session);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.get("/strength-conditioning/:id", async (req, res) => {
  try {
    const [session] = await db.select().from(strengthConditioningTable).where(eq(strengthConditioningTable.id, Number(req.params.id)));
    if (!session) return res.status(404).json({ error: "Not found" });
    res.json(session);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch S&C session" });
  }
});

router.put("/strength-conditioning/:id", async (req, res) => {
  try {
    const data = insertStrengthConditioningSchema.parse(req.body);
    const [session] = await db.update(strengthConditioningTable).set(data).where(eq(strengthConditioningTable.id, Number(req.params.id))).returning();
    if (!session) return res.status(404).json({ error: "Not found" });
    res.json(session);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.delete("/strength-conditioning/:id", async (req, res) => {
  try {
    await db.delete(strengthConditioningTable).where(eq(strengthConditioningTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: "Failed to delete S&C session" });
  }
});

export default router;
