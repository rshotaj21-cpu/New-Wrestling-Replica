import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { settingsTable } from "@workspace/db/schema";

const router: IRouter = Router();

router.get("/settings", async (_req, res) => {
  try {
    const rows = await db.select().from(settingsTable);
    if (rows.length === 0) {
      const [row] = await db.insert(settingsTable).values({ weeklySessionsTarget: 3 }).returning();
      return res.json({ weeklySessionsTarget: row.weeklySessionsTarget });
    }
    res.json({ weeklySessionsTarget: rows[0].weeklySessionsTarget });
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch settings" });
  }
});

router.put("/settings", async (req, res) => {
  try {
    const { weeklySessionsTarget } = req.body;
    const rows = await db.select().from(settingsTable);
    let row;
    if (rows.length === 0) {
      [row] = await db.insert(settingsTable).values({ weeklySessionsTarget }).returning();
    } else {
      const { eq } = await import("drizzle-orm");
      [row] = await db.update(settingsTable).set({ weeklySessionsTarget }).where(eq(settingsTable.id, rows[0].id)).returning();
    }
    res.json({ weeklySessionsTarget: row.weeklySessionsTarget });
  } catch (e) {
    res.status(500).json({ error: "Failed to update settings" });
  }
});

export default router;
