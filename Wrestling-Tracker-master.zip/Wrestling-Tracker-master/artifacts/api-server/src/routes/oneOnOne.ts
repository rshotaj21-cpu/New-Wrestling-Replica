import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { oneOnOneTable, insertOneOnOneSchema } from "@workspace/db/schema";
import { eq, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/one-on-one", async (_req, res) => {
  try {
    const rows = await db.select().from(oneOnOneTable).orderBy(sql`${oneOnOneTable.date} DESC`);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch" });
  }
});

router.post("/one-on-one", async (req, res) => {
  try {
    const data = insertOneOnOneSchema.parse(req.body);
    const [row] = await db.insert(oneOnOneTable).values(data).returning();
    res.status(201).json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.put("/one-on-one/:id", async (req, res) => {
  try {
    const data = insertOneOnOneSchema.parse(req.body);
    const [row] = await db.update(oneOnOneTable).set(data).where(eq(oneOnOneTable.id, Number(req.params.id))).returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.delete("/one-on-one/:id", async (req, res) => {
  try {
    await db.delete(oneOnOneTable).where(eq(oneOnOneTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: "Failed to delete" });
  }
});

export default router;
