import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { focusTable, insertFocusSchema } from "@workspace/db/schema";
import { eq, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/focus", async (_req, res) => {
  try {
    const rows = await db.select().from(focusTable).orderBy(sql`${focusTable.date} DESC`);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch focus sessions" });
  }
});

router.post("/focus", async (req, res) => {
  try {
    const data = insertFocusSchema.parse(req.body);
    const [row] = await db.insert(focusTable).values(data).returning();
    res.status(201).json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.put("/focus/:id", async (req, res) => {
  try {
    const data = insertFocusSchema.parse(req.body);
    const [row] = await db.update(focusTable).set(data).where(eq(focusTable.id, Number(req.params.id))).returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.delete("/focus/:id", async (req, res) => {
  try {
    await db.delete(focusTable).where(eq(focusTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: "Failed to delete" });
  }
});

export default router;
