import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { sessionsTable, insertSessionSchema } from "@workspace/db/schema";
import { eq, and, gte, lte, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/sessions", async (req, res) => {
  try {
    const { month, year } = req.query;
    let query = db.select().from(sessionsTable);
    if (year && month) {
      const y = Number(year);
      const m = Number(month);
      const start = `${y}-${String(m).padStart(2, "0")}-01`;
      const end = `${y}-${String(m).padStart(2, "0")}-31`;
      const sessions = await db.select().from(sessionsTable)
        .where(and(gte(sessionsTable.date, start), lte(sessionsTable.date, end)))
        .orderBy(sql`${sessionsTable.date} DESC`);
      res.json(sessions);
    } else {
      const sessions = await db.select().from(sessionsTable)
        .orderBy(sql`${sessionsTable.date} DESC`);
      res.json(sessions);
    }
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch sessions" });
  }
});

router.post("/sessions", async (req, res) => {
  try {
    const data = insertSessionSchema.parse(req.body);
    const [session] = await db.insert(sessionsTable).values(data).returning();
    res.status(201).json(session);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.get("/sessions/:id", async (req, res) => {
  try {
    const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, Number(req.params.id)));
    if (!session) return res.status(404).json({ error: "Not found" });
    res.json(session);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch session" });
  }
});

router.put("/sessions/:id", async (req, res) => {
  try {
    const data = insertSessionSchema.parse(req.body);
    const [session] = await db.update(sessionsTable).set(data).where(eq(sessionsTable.id, Number(req.params.id))).returning();
    if (!session) return res.status(404).json({ error: "Not found" });
    res.json(session);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.delete("/sessions/:id", async (req, res) => {
  try {
    await db.delete(sessionsTable).where(eq(sessionsTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: "Failed to delete" });
  }
});

export default router;
