import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { competitionsTable, insertCompetitionSchema } from "@workspace/db/schema";
import { eq, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/competitions", async (_req, res) => {
  try {
    const rows = await db.select().from(competitionsTable).orderBy(sql`${competitionsTable.date} DESC`);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch competitions" });
  }
});

router.post("/competitions", async (req, res) => {
  try {
    const data = insertCompetitionSchema.parse(req.body);
    const [row] = await db.insert(competitionsTable).values(data).returning();
    res.status(201).json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.get("/competitions/:id", async (req, res) => {
  try {
    const [row] = await db.select().from(competitionsTable).where(eq(competitionsTable.id, Number(req.params.id)));
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(row);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch" });
  }
});

router.put("/competitions/:id", async (req, res) => {
  try {
    const data = insertCompetitionSchema.parse(req.body);
    const [row] = await db.update(competitionsTable).set(data).where(eq(competitionsTable.id, Number(req.params.id))).returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.delete("/competitions/:id", async (req, res) => {
  try {
    await db.delete(competitionsTable).where(eq(competitionsTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: "Failed to delete" });
  }
});

export default router;
