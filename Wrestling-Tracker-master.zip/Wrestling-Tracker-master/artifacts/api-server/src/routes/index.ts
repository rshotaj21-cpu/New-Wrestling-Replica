import { Router, type IRouter } from "express";
import healthRouter from "./health";
import sessionsRouter from "./sessions";
import sparringRouter from "./sparring";
import techniquesRouter from "./techniques";
import competitionsRouter from "./competitions";
import focusRouter from "./focus";
import statsRouter from "./stats";
import oneOnOneRouter from "./oneOnOne";
import settingsRouter from "./settings";
import strengthConditioningRouter from "./strengthConditioning";

const router: IRouter = Router();

router.use(healthRouter);
router.use(sessionsRouter);
router.use(sparringRouter);
router.use(techniquesRouter);
router.use(competitionsRouter);
router.use(focusRouter);
router.use(statsRouter);
router.use(oneOnOneRouter);
router.use(settingsRouter);
router.use(strengthConditioningRouter);

export default router;
