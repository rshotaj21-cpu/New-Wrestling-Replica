import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { techniquesTable, insertTechniqueSchema } from "@workspace/db/schema";
import { eq, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/techniques", async (_req, res) => {
  try {
    const rows = await db.select().from(techniquesTable).orderBy(sql`${techniquesTable.date} DESC`);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch techniques" });
  }
});

router.post("/techniques", async (req, res) => {
  try {
    const data = insertTechniqueSchema.parse(req.body);
    const [row] = await db.insert(techniquesTable).values(data).returning();
    res.status(201).json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.put("/techniques/:id", async (req, res) => {
  try {
    const data = insertTechniqueSchema.parse(req.body);
    const [row] = await db.update(techniquesTable).set(data).where(eq(techniquesTable.id, Number(req.params.id))).returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.delete("/techniques/:id", async (req, res) => {
  try {
    await db.delete(techniquesTable).where(eq(techniquesTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: "Failed to delete" });
  }
});

export default router;
