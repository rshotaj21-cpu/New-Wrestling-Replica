import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { sessionsTable, sparringTable, competitionsTable, focusTable, oneOnOneTable, settingsTable, strengthConditioningTable } from "@workspace/db/schema";
import { eq, gte, sql, sum, asc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/stats", async (_req, res) => {
  try {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const startOfYear = `${year}-01-01`;
    const startOfMonth = `${year}-${String(month).padStart(2, "0")}-01`;
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    const weekStr = startOfWeek.toISOString().split("T")[0];

    const [totalSessionsResult] = await db.select({ count: sql<number>`count(*)` }).from(sessionsTable);
    const [weekResult] = await db.select({ count: sql<number>`count(*)` }).from(sessionsTable).where(gte(sessionsTable.date, weekStr));
    const [monthResult] = await db.select({ count: sql<number>`count(*)` }).from(sessionsTable).where(gte(sessionsTable.date, startOfMonth));
    const [yearResult] = await db.select({ count: sql<number>`count(*)` }).from(sessionsTable).where(gte(sessionsTable.date, startOfYear));

    const [sparringResult] = await db.select({ total: sum(sparringTable.rounds) }).from(sparringTable);
    const [avgRatingResult] = await db.select({ avg: sql<number>`avg(${sessionsTable.rating})` }).from(sessionsTable);
    const [avgDurationResult] = await db.select({ avg: sql<number>`avg(${sessionsTable.durationMinutes})` }).from(sessionsTable);
    const [avgEnduranceResult] = await db.select({ avg: sql<number>`avg(${sparringTable.enduranceRating})` }).from(sparringTable);

    const [upcomingResult] = await db.select({ count: sql<number>`count(*)` }).from(competitionsTable).where(eq(competitionsTable.status, "upcoming"));
    const [totalCompsResult] = await db.select({ count: sql<number>`count(*)` }).from(competitionsTable);
    const [winsResult] = await db.select({ total: sum(competitionsTable.wins) }).from(competitionsTable);
    const [lossesResult] = await db.select({ total: sum(competitionsTable.losses) }).from(competitionsTable);
    const [matchesResult] = await db.select({ total: sum(competitionsTable.totalMatches) }).from(competitionsTable);

    const [focusResult] = await db.select({ count: sql<number>`count(*)` }).from(focusTable);

    // Mat time
    const [sessionMatTime] = await db.select({ total: sum(sessionsTable.durationMinutes) }).from(sessionsTable);
    const [sparringMatTime] = await db.select({ total: sql<number>`sum(${sparringTable.rounds} * ${sparringTable.roundDurationSeconds} / 60)` }).from(sparringTable);
    const [oneOnOneResult] = await db.select({ count: sql<number>`count(*)` }).from(oneOnOneTable);
    const [oneOnOneMatTime] = await db.select({ total: sum(oneOnOneTable.durationMinutes) }).from(oneOnOneTable);

    // S&C stats
    const [scCountResult] = await db.select({ count: sql<number>`count(*)` }).from(strengthConditioningTable);
    const [scMatTimeResult] = await db.select({ total: sum(strengthConditioningTable.durationMinutes) }).from(strengthConditioningTable);

    const totalMinutes = (Number(sessionMatTime.total) || 0) + (Number(sparringMatTime.total) || 0) + (Number(oneOnOneMatTime.total) || 0);
    const totalMatTimeHours = Math.round((totalMinutes / 60) * 10) / 10;
    const totalScMinutes = Number(scMatTimeResult.total) || 0;
    const totalScTimeHours = Math.round((totalScMinutes / 60) * 10) / 10;

    // Calculate current weekly streak
    const allSessionDates = await db
      .select({ date: sessionsTable.date })
      .from(sessionsTable)
      .orderBy(asc(sessionsTable.date));

    const weeksWithSessions = new Set<string>();
    for (const row of allSessionDates) {
      const d = new Date(row.date + "T00:00:00");
      const weekNum = getISOWeek(d);
      const yr = d.getFullYear();
      weeksWithSessions.add(`${yr}-${weekNum}`);
    }

    const currentWeek = getISOWeek(now);
    const currentYear = now.getFullYear();
    let streak = 0;
    let checkWeek = currentWeek;
    let checkYear = currentYear;
    while (weeksWithSessions.has(`${checkYear}-${checkWeek}`)) {
      streak++;
      checkWeek--;
      if (checkWeek < 1) { checkWeek = 52; checkYear--; }
      if (streak > 200) break;
    }

    // Get user settings
    const settingsRows = await db.select().from(settingsTable);
    const weeklyTarget = settingsRows.length > 0 ? settingsRows[0].weeklySessionsTarget : 3;

    res.json({
      totalSessions: Number(totalSessionsResult.count) || 0,
      sessionsThisWeek: Number(weekResult.count) || 0,
      sessionsThisMonth: Number(monthResult.count) || 0,
      sessionsThisYear: Number(yearResult.count) || 0,
      totalSparringRounds: Number(sparringResult.total) || 0,
      avgSessionRating: avgRatingResult.avg ? Number(avgRatingResult.avg) : null,
      avgSessionLengthMinutes: avgDurationResult.avg ? Math.round(Number(avgDurationResult.avg)) : null,
      avgEnduranceRating: avgEnduranceResult.avg ? Number(avgEnduranceResult.avg) : null,
      upcomingCompetitions: Number(upcomingResult.count) || 0,
      totalCompetitions: Number(totalCompsResult.count) || 0,
      totalCompetitionMatches: Number(matchesResult.total) || 0,
      totalWins: Number(winsResult.total) || 0,
      totalLosses: Number(lossesResult.total) || 0,
      totalFocusSessions: Number(focusResult.count) || 0,
      totalMatTimeHours,
      oneOnOneCount: Number(oneOnOneResult.count) || 0,
      weeklySessionsTarget: weeklyTarget,
      currentStreak: streak,
      totalScSessions: Number(scCountResult.count) || 0,
      totalScTimeHours,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});

function getISOWeek(d: Date): number {
  const date = new Date(d);
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() + 3 - ((date.getDay() + 6) % 7));
  const week1 = new Date(date.getFullYear(), 0, 4);
  return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + ((week1.getDay() + 6) % 7)) / 7);
}

export default router;
