import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { sparringTable, insertSparringSchema } from "@workspace/db/schema";
import { eq, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/sparring", async (_req, res) => {
  try {
    const rows = await db.select().from(sparringTable).orderBy(sql`${sparringTable.date} DESC`);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch sparring sessions" });
  }
});

router.post("/sparring", async (req, res) => {
  try {
    const data = insertSparringSchema.parse(req.body);
    const [row] = await db.insert(sparringTable).values(data).returning();
    res.status(201).json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.get("/sparring/:id", async (req, res) => {
  try {
    const [row] = await db.select().from(sparringTable).where(eq(sparringTable.id, Number(req.params.id)));
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(row);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch" });
  }
});

router.put("/sparring/:id", async (req, res) => {
  try {
    const data = insertSparringSchema.parse(req.body);
    const [row] = await db.update(sparringTable).set(data).where(eq(sparringTable.id, Number(req.params.id))).returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(row);
  } catch (e) {
    res.status(400).json({ error: "Invalid data" });
  }
});

router.delete("/sparring/:id", async (req, res) => {
  try {
    await db.delete(sparringTable).where(eq(sparringTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: "Failed to delete" });
  }
});

export default router;
