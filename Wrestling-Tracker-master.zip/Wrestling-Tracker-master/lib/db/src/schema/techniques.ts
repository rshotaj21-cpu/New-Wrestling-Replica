import { pgTable, text, serial, integer, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const techniquesTable = pgTable("techniques", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id"),
  name: text("name").notNull(),
  category: text("category").notNull(),
  repsInSparring: integer("reps_in_sparring"),
  successRate: integer("success_rate"),
  notes: text("notes"),
  date: date("date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTechniqueSchema = createInsertSchema(techniquesTable).omit({ id: true, createdAt: true });
export type InsertTechnique = z.infer<typeof insertTechniqueSchema>;
export type Technique = typeof techniquesTable.$inferSelect;
