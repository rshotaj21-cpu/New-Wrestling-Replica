import { pgTable, text, serial, integer, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const oneOnOneTable = pgTable("one_on_one_sessions", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  coachName: text("coach_name").notNull(),
  durationMinutes: integer("duration_minutes").notNull(),
  whatLearned: text("what_learned"),
  keyTechniques: text("key_techniques"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOneOnOneSchema = createInsertSchema(oneOnOneTable).omit({ id: true, createdAt: true });
export type InsertOneOnOne = z.infer<typeof insertOneOnOneSchema>;
export type OneOnOne = typeof oneOnOneTable.$inferSelect;
