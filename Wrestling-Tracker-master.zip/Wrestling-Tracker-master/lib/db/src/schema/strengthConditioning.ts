import { pgTable, text, serial, integer, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const strengthConditioningTable = pgTable("strength_conditioning", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  sessionType: text("session_type").notNull(),
  sessionFocus: text("session_focus").notNull(),
  durationMinutes: integer("duration_minutes").notNull(),
  rpe: integer("rpe").notNull(),
  exercises: text("exercises"),
  conditioningType: text("conditioning_type"),
  conditioningDetails: text("conditioning_details"),
  conditioningEffort: integer("conditioning_effort"),
  wentWell: text("went_well"),
  needsWork: text("needs_work"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertStrengthConditioningSchema = createInsertSchema(strengthConditioningTable).omit({ id: true, createdAt: true });
export type InsertStrengthConditioning = z.infer<typeof insertStrengthConditioningSchema>;
export type StrengthConditioning = typeof strengthConditioningTable.$inferSelect;
