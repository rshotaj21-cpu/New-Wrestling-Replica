import { pgTable, text, serial, integer, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const focusTable = pgTable("focus_sessions", {
  id: serial("id").primaryKey(),
  techniqueName: text("technique_name").notNull(),
  targetReps: integer("target_reps").notNull(),
  completedReps: integer("completed_reps").notNull().default(0),
  repGoal: integer("rep_goal"),
  durationMinutes: integer("duration_minutes").notNull(),
  focusPeriodDays: integer("focus_period_days"),
  drillMethod: text("drill_method"),
  gamePlanNotes: text("game_plan_notes"),
  focusReason: text("focus_reason"),
  progress: text("progress").notNull().default("planned"),
  notes: text("notes"),
  date: date("date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertFocusSchema = createInsertSchema(focusTable).omit({ id: true, createdAt: true });
export type InsertFocus = z.infer<typeof insertFocusSchema>;
export type Focus = typeof focusTable.$inferSelect;
