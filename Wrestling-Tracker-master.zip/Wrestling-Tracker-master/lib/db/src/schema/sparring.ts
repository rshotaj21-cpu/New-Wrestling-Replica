import { pgTable, text, serial, integer, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sparringTable = pgTable("sparring", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id"),
  date: date("date").notNull(),
  rounds: integer("rounds").notNull(),
  roundDurationSeconds: integer("round_duration_seconds").notNull(),
  enduranceRating: integer("endurance_rating").notNull(),
  roundsRating: integer("rounds_rating").notNull(),
  wentWell: text("went_well"),
  needsWork: text("needs_work"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSparringSchema = createInsertSchema(sparringTable).omit({ id: true, createdAt: true });
export type InsertSparring = z.infer<typeof insertSparringSchema>;
export type Sparring = typeof sparringTable.$inferSelect;
